"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowRight,
  ArrowLeft,
  Globe2,
  Sparkles,
  Plus,
  Play,
  Pause,
  Send,
  Download,
  Copy,
  Check,
  Trash2,
  ShieldCheck,
  Users,
  MessageCircle,
  ChevronRight,
  BookOpen,
  RotateCcw,
  LoaderCircle,
  X,
  Scale,
  FlaskConical,
  HeartHandshake,
  Landmark,
  BriefcaseBusiness,
  GraduationCap,
  Cpu,
  UsersRound,
  Compass,
  Lightbulb,
  Search,
  ScrollText,
  UserRound,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogFooter,
} from "@/components/ui/alert-dialog";
import {
  Combobox,
  ComboboxInput,
  ComboboxContent,
  ComboboxList,
  ComboboxItem,
  ComboboxEmpty,
} from "@/components/ui/combobox";
import {
  catalogue,
  categories,
  groups,
  goals,
  dailyQuestionSuggestions,
  suggest,
  initialSession,
  validateSession,
  nextSpeaker,
  nameOf,
  kindLabel,
  type Profile,
  type QuestionIdea,
  type Session,
  type Lang,
} from "@/lib/roundtable";
import CouncilMark from "@/components/council-mark";
import PersonaExplorer, { LibraryIcon } from "@/components/persona-explorer";
import AccountGate, {
  consumeDiscussion,
  currentBrowserAccount,
  signOutBrowserAccount,
  type BrowserAccount,
} from "@/components/account-gate";
import DiscussionDashboard, {
  type DiscussionRecord,
} from "@/components/discussion-dashboard";
import AccountMenu from "@/components/account-menu";
const STORAGE = "roundtable.session.v1";
const HISTORY_STORAGE = "council.discussions.v1";
const ACTIVE_STORAGE = "council.active-discussion.v1";
async function loadAccountDiscussions() {
  const response = await fetch("/api/discussions", { cache: "no-store" });
  if (!response.ok) return [];
  const data = (await response.json()) as { items?: DiscussionRecord[] };
  return Array.isArray(data.items) ? data.items : [];
}
async function saveAccountDiscussion(item: DiscussionRecord) {
  await fetch("/api/discussions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(item),
  });
}
function Choice({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[][];
  onChange: (v: string) => void;
}) {
  return (
    <div className="choice">
      <span className="field-label">{label}</span>
      <Select value={value} onValueChange={(v) => v !== null && onChange(v)}>
        <SelectTrigger aria-label={label} className="choice-trigger">
          <SelectValue>
            {options.find((o) => o[0] === value)?.[1] || value}
          </SelectValue>
        </SelectTrigger>
        <SelectContent alignItemWithTrigger={false}>
          {options.map(([v, t]) => (
            <SelectItem key={v} value={v}>
              {t}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
function PerspectiveIcon({ p, size = 24 }: { p: Profile; size?: number }) {
  const props = { size, "aria-hidden": true as const, strokeWidth: 1.8 };
  if (p.library) return <LibraryIcon domain={p.library.Domain} />;
  if (p.id === "socrates" || /question|تساؤل/.test(p.role + " " + p.roleAr))
    return <Search {...props} />;
  if (p.id === "scientist") return <FlaskConical {...props} />;
  if (
    p.id === "ethicist" ||
    p.id === "kant" ||
    p.id === "mill" ||
    p.id === "nussbaum"
  )
    return <Scale {...props} />;
  if (p.id === "strategist" || p.id === "economist" || p.id === "investor")
    return <BriefcaseBusiness {...props} />;
  if (
    p.id === "educator" ||
    p.id === "student" ||
    p.id === "dewey" ||
    p.id === "wollstonecraft"
  )
    return <GraduationCap {...props} />;
  if (p.id === "technologist" || p.id === "russell" || p.id === "feifei")
    return <Cpu {...props} />;
  if (p.id === "counselor" || p.id === "mediator" || p.id === "parent")
    return <HeartHandshake {...props} />;
  if (p.id === "historian" || p.id === "ibnkhaldun")
    return <Landmark {...props} />;
  if (["islamic", "christian", "buddhist", "jewish"].includes(p.id))
    return <ScrollText {...props} />;
  if (p.id === "community" || p.id === "employee" || p.id === "customer")
    return <UsersRound {...props} />;
  if (p.id === "aristotle" || p.id === "humanist")
    return <Compass {...props} />;
  if (p.kind === "public") return <Lightbulb {...props} />;
  if (p.group === "stakeholder") return <UsersRound {...props} />;
  if (p.kind === "custom") return <UserRound {...props} />;
  if (p.tags.includes("technology")) return <Cpu {...props} />;
  if (p.tags.includes("education")) return <GraduationCap {...props} />;
  if (p.tags.includes("business")) return <BriefcaseBusiness {...props} />;
  return <BookOpen {...props} />;
}
function Table({
  people,
  lang,
  onSelect,
  speaking,
  selected,
  turn = 0,
  stage,
}: {
  people: Profile[];
  lang: Lang;
  onSelect: (n: number) => void;
  speaking: number;
  selected: number | null;
  turn?: number;
  stage: string;
}) {
  const ar = lang === "ar";
  if (stage === "discuss")
    return (
      <CompactTable
        people={people}
        lang={lang}
        speaking={speaking}
        onSelect={onSelect}
      />
    );
  const angleStart = people.length === 2 ? 180 : -90;
  return (
    <div
      className="table-stage"
      aria-label={
        ar
          ? `طاولة بعدد ${people.length} من المقاعد`
          : `Table with ${people.length} seats`
      }
    >
      <div className="table-disc">
        <span>{ar ? "المجلس" : "THE COUNCIL"}</span>
        <strong>
          {ar ? (
            <>
              مساحة
              <br />
              لمنظور آخر.
            </>
          ) : (
            <>
              Room for
              <br />
              another perspective.
            </>
          )}
        </strong>
        <i>
          {ar
            ? `${people.length} أصوات. وأنت المضيف.`
            : `${people.length} minds. You host.`}
        </i>
      </div>
      {people.map((p, i) => {
        const angle =
          ((angleStart + (i * 360) / people.length) * Math.PI) / 180;
        return (
          <button
            key={i}
            className={`seat ${speaking === i ? "speaking" : ""} ${selected === i ? "selected" : ""}`}
            style={{
              left: `${50 + 38 * Math.cos(angle)}%`,
              top: `${50 + 38 * Math.sin(angle)}%`,
            }}
            onClick={() => onSelect(i)}
            aria-label={`${ar ? "المقعد" : "Seat"} ${i + 1}: ${nameOf(p, lang)}. ${ar ? "تغيير المشارك" : "Change participant"}`}
            aria-pressed={selected === i}
          >
            <span className={`avatar color-${i}`}>
              <PerspectiveIcon p={p} />
              <span className="seat-number">{i + 1}</span>
            </span>
            <b>{nameOf(p, lang)}</b>
            <small>
              {speaking === i
                ? ar
                  ? "يتحدث الآن"
                  : "Speaking now"
                : ar
                  ? p.roleAr
                  : p.role}
            </small>
          </button>
        );
      })}
    </div>
  );
}
function CompactTable({
  people,
  lang,
  speaking,
  onSelect,
}: {
  people: Profile[];
  lang: Lang;
  speaking: number;
  onSelect: (n: number) => void;
}) {
  const ar = lang === "ar";
  return (
    <>
      <div
        className="compact-table"
        style={{
          gridTemplateColumns: `repeat(${people.length},minmax(0,1fr))`,
        }}
        aria-label={
          ar ? `${people.length} مشاركين` : `${people.length} participants`
        }
      >
        {people.map((p, i) => (
          <button
            key={p.id}
            className={speaking === i ? "speaking" : ""}
            onClick={() => onSelect(i)}
            aria-label={`${ar ? "تغيير" : "Change"} ${nameOf(p, lang)}`}
          >
            <span className={`mini-avatar color-${i}`}>
              <PerspectiveIcon p={p} size={18} />
            </span>
            <span>
              <b>{nameOf(p, lang)}</b>
              <small>
                {speaking === i
                  ? ar
                    ? "يتحدث الآن"
                    : "Speaking now"
                  : ar
                    ? p.roleAr
                    : p.role}
              </small>
            </span>
          </button>
        ))}
      </div>
    </>
  );
}
const inlineText = (value: string): ReactNode[] =>
  value
    .split(/(\*\*[^*]+\*\*)/g)
    .filter(Boolean)
    .map((part, index) =>
      part.startsWith("**") && part.endsWith("**") ? (
        <strong key={index}>{part.slice(2, -2)}</strong>
      ) : (
        <span key={index}>{part}</span>
      ),
    );
const tableCells = (line: string) =>
  line.trim().replace(/^\||\|$/g, "").split("|").map((cell) => cell.trim());
function FormattedText({ text }: { text: string }) {
  const lines = text.split("\n");
  const blocks: ReactNode[] = [];
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (
      line.includes("|") &&
      index + 1 < lines.length &&
      /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(
        lines[index + 1],
      )
    ) {
      const headers = tableCells(line);
      const rows: string[][] = [];
      index += 2;
      while (index < lines.length && lines[index].includes("|")) {
        rows.push(tableCells(lines[index]));
        index += 1;
      }
      index -= 1;
      blocks.push(
        <div className="message-table-wrap" key={`table-${index}`}>
          <table className="message-table">
            <thead><tr>{headers.map((cell, cellIndex) => <th key={cellIndex}>{inlineText(cell)}</th>)}</tr></thead>
            <tbody>{rows.map((row, rowIndex) => <tr key={rowIndex}>{headers.map((_, cellIndex) => <td key={cellIndex}>{inlineText(row[cellIndex] || "")}</td>)}</tr>)}</tbody>
          </table>
        </div>,
      );
      continue;
    }
    const bullet = line.match(/^\s*(?:[-*]|\d+[.)])\s+(.+)$/);
    if (bullet) {
      blocks.push(<div className="formatted-list-line" key={index}><span aria-hidden="true">•</span><span>{inlineText(bullet[1])}</span></div>);
      continue;
    }
    const heading = line.match(/^#{1,4}\s+(.+)$/);
    blocks.push(<span className={heading ? "formatted-line formatted-heading" : "formatted-line"} key={index}>{inlineText(heading?.[1] || line)}</span>);
  }
  return <div className="formatted-text">{blocks}</div>;
}
export default function Home() {
  const [s, setS] = useState<Session>(initialSession);
  const [ready, setReady] = useState(false);
  const [dayKey, setDayKey] = useState(() => Math.floor((Date.now() + 10800000) / 86400000));
  const [dailyQuestionPool, setDailyQuestionPool] = useState<QuestionIdea[]>([]);
  const [mode, setMode] = useState("checking");
  const [busy, setBusy] = useState(false);
  const [busySeconds, setBusySeconds] = useState(0);
  const [autoplay, setAutoplay] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [selected, setSelected] = useState<number | null>(null);
  const [group, setGroup] = useState("all");
  const [customForm, setCustomForm] = useState(false);
  const [editingId, setEditingId] = useState("");
  const [draft, setDraft] = useState({
    name: "",
    background: "",
    perspective: "",
    priorities: "",
  });
  const [host, setHost] = useState("");
  const [target, setTarget] = useState("all");
  const [debateWith, setDebateWith] = useState("");
  const [showSynthesis, setShowSynthesis] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [speaking, setSpeaking] = useState(-1);
  const [account, setAccount] = useState<BrowserAccount | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [remaining, setRemaining] = useState(2);
  const [assembling, setAssembling] = useState(false);
  const [history, setHistory] = useState<DiscussionRecord[]>([]);
  const [activeId, setActiveId] = useState("");
  const [showDashboard, setShowDashboard] = useState(false);
  const current = useRef(s);
  const historyRef = useRef(history);
  const flight = useRef<AbortController | null>(null);
  const epoch = useRef(0);
  const lock = useRef(false);
  const end = useRef<HTMLDivElement>(null);
  const lastAction = useRef<"contribution" | "synthesis">("contribution");
  const retryId = useRef("");
  current.current = s;
  historyRef.current = history;
  const ar = s.lang === "ar";
  const participantCount = s.participantCount ?? 5;
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  const opts = (rows: string[][]) => rows.map((r) => [r[0], r[ar ? 2 : 1]]);
  const update = (patch: Partial<Session>) => setS((v) => ({ ...v, ...patch }));
  const busyLabel =
    lastAction.current === "synthesis"
      ? busySeconds < 12
        ? t("Reviewing the discussion…", "جارٍ مراجعة النقاش…")
        : busySeconds < 30
          ? t(
              "Organizing agreements and disagreements…",
              "جارٍ تنظيم نقاط الاتفاق والخلاف…",
            )
          : t(
              "Writing the decision-ready synthesis…",
              "جارٍ صياغة خلاصة عملية…",
            )
      : busySeconds < 8
        ? t("Reading the question and context…", "جارٍ قراءة السؤال والسياق…")
        : busySeconds < 20
          ? t("Applying the speaker’s expertise…", "جارٍ تطبيق خبرة المتحدث…")
          : t(
              "Checking assumptions and evidence…",
              "جارٍ فحص الافتراضات والأدلة…",
            );
  useEffect(() => {
    let live = true;
    const restore = async () => {
      try {
        const savedAccount = await currentBrowserAccount();
        const stored = localStorage.getItem(STORAGE);
        const restored = stored ? JSON.parse(stored) : null;
        const restoredSession = validateSession(restored) ? restored : null;
        const savedHistory = JSON.parse(
          localStorage.getItem(HISTORY_STORAGE) || "[]",
        );
        const records: DiscussionRecord[] = Array.isArray(savedHistory)
          ? savedHistory.filter((item): item is DiscussionRecord =>
              Boolean(
                item &&
                  typeof item.id === "string" &&
                  typeof item.owner === "string" &&
                  typeof item.updatedAt === "number" &&
                  validateSession(item.session),
              ),
            )
          : [];
        let id = localStorage.getItem(ACTIVE_STORAGE) || "";
        if (!id) id = crypto.randomUUID();
        if (
          restoredSession &&
          savedAccount &&
          restoredSession.question.trim() &&
          restoredSession.stage !== "start"
        ) {
          const record = {
            id,
            owner: savedAccount.email,
            updatedAt: Date.now(),
            session: restoredSession,
          };
          const next = [
            record,
            ...records.filter((item) => item.id !== id),
          ].slice(0, 50);
          for (const item of next)
            await saveAccountDiscussion(item).catch(() => undefined);
          const synced = savedAccount ? await loadAccountDiscussions() : next;
          setHistory(synced);
          localStorage.setItem(HISTORY_STORAGE, JSON.stringify(next));
          setShowDashboard(Boolean(savedAccount));
        } else {
          if (savedAccount) {
            for (const item of records.filter(
              (record) => record.owner === savedAccount.email,
            ))
              await saveAccountDiscussion(item).catch(() => undefined);
            setHistory(await loadAccountDiscussions());
            setShowDashboard(true);
          } else setHistory(records);
        }
        if (restoredSession) setS(restoredSession);
        else if (stored)
          setNotice(
            "The saved session could not be restored. / تعذر استعادة الجلسة المحفوظة.",
          );
        setActiveId(id);
        localStorage.setItem(ACTIVE_STORAGE, id);
        if (live) {
          setAccount(savedAccount);
          setRemaining(savedAccount?.usage.remaining ?? 2);
        }
      } catch {
        setNotice("Session storage is unavailable. / تخزين الجلسة غير متاح.");
      }
      if (live) {
        setReady(true);
        setAuthReady(true);
      }
      fetch("/api/discuss")
        .then((r) => (r.ok ? r.json() : Promise.reject()))
        .then((v) => setMode((v as { mode: string }).mode))
        .catch(() => setMode("offline"));
    };
    restore();
    return () => {
      live = false;
      flight.current?.abort();
    };
  }, []);
  useEffect(() => {
    let live = true;
    fetch("/api/questions?v=2", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : Promise.reject()))
      .then((value) => {
        const data = value as { questions?: QuestionIdea[]; day?: string };
        if (!live || !Array.isArray(data.questions)) return;
        const valid = data.questions.filter(
          (row): row is QuestionIdea =>
            Array.isArray(row) &&
            row.length === 3 &&
            row.every((item) => typeof item === "string"),
        );
        if (valid.length >= 5) setDailyQuestionPool(valid);
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [dayKey]);
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE, JSON.stringify(s));
      if (account && activeId && s.question.trim() && s.stage !== "start") {
        const record: DiscussionRecord = {
          id: activeId,
          owner: account.email,
          updatedAt: Date.now(),
          session: s,
        };
        setHistory((previous) => {
          const next = [
            {
              ...record,
              title: previous.find((item) => item.id === activeId)?.title || "",
            },
            ...previous.filter((item) => item.id !== activeId),
          ].slice(0, 50);
          localStorage.setItem(HISTORY_STORAGE, JSON.stringify(next));
          return next;
        });
        const existingTitle =
          historyRef.current.find((item) => item.id === activeId)?.title || "";
        const timer = window.setTimeout(
          () =>
            saveAccountDiscussion({ ...record, title: existingTitle }).catch(
              () => undefined,
            ),
          500,
        );
        localStorage.setItem(ACTIVE_STORAGE, activeId);
        return () => window.clearTimeout(timer);
      }
    } catch {
      setNotice(
        t(
          "Your browser could not save this session. Download a copy before leaving.",
          "تعذر حفظ الجلسة في المتصفح. نزّل نسخة قبل المغادرة.",
        ),
      );
    }
  }, [s, ready, account, activeId]);
  useEffect(() => {
    document.documentElement.lang = s.lang;
    document.documentElement.dir = ar ? "rtl" : "ltr";
  }, [s.lang, ar]);
  useEffect(() => {
    const panel = end.current?.parentElement;
    if (panel) panel.scrollTop = panel.scrollHeight;
  }, [s.messages.length, busy]);
  useEffect(() => {
    const timer = setInterval(
      () => setDayKey(Math.floor((Date.now() + 10800000) / 86400000)),
      60000,
    );
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!busy) {
      setBusySeconds(0);
      return;
    }
    const started = Date.now();
    const timer = setInterval(
      () => setBusySeconds(Math.floor((Date.now() - started) / 1000)),
      1000,
    );
    return () => clearInterval(timer);
  }, [busy]);
  const stop = () => {
    setAutoplay(false);
    epoch.current++;
    flight.current?.abort();
    flight.current = null;
    lock.current = false;
    setBusy(false);
    setSpeaking(-1);
  };
  const replace = (p: Profile) => {
    if (selected === null) return;
    stop();
    const seat = selected;
    const old = s.participants[seat];
    if (s.participants.some((v, i) => v.id === p.id && i !== seat)) {
      setNotice(
        t(
          "That perspective is already seated.",
          "هذا المنظور موجود على الطاولة.",
        ),
      );
      return;
    }
    setS((v) => ({
      ...v,
      participants: v.participants.map((x, i) => (i === seat ? p : x)),
      queue: [],
      messages:
        v.stage === "discuss"
          ? [
              ...v.messages,
              {
                id: crypto.randomUUID(),
                type: "event",
                name: t("Table update", "تحديث الطاولة"),
                text: t(
                  `${old.name} left seat ${seat + 1}. ${p.name} joined; earlier contributions are preserved.`,
                  `${nameOf(old, "ar")} غادر المقعد ${seat + 1}. انضم ${nameOf(p, "ar")}؛ المساهمات السابقة محفوظة.`,
                ),
              },
            ]
          : v.messages,
    }));
    setSelected(null);
    setCustomForm(false);
    setTarget("all");
    setDebateWith("");
  };
  const assemble = async () => {
    if (!s.question.trim() || assembling) return;
    stop();
    setAssembling(true);
    setError("");
    try {
      const response = await fetch("/api/personas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: s.question,
          category: s.category,
          lang: s.lang,
          count: participantCount,
        }),
      });
      const data = (await response.json()) as {
        selections?: {
          id: string;
          reason: string;
          position: string;
          tension: string;
          reconsider: string;
        }[];
      };
      if (!response.ok || !Array.isArray(data.selections))
        throw new Error("MATCHING_FAILED");
      const participants = data.selections
        .map((row) => {
          const profile = catalogue.find((item) => item.id === row.id);
          return profile
            ? {
                ...profile,
                reason: row.reason,
                councilBrief: {
                  position: row.position,
                  tension: row.tension,
                  reconsider: row.reconsider,
                },
              }
            : null;
        })
        .filter(Boolean) as Profile[];
      if (participants.length !== participantCount)
        throw new Error("MATCHING_FAILED");
      update({ participants, stage: "assemble" });
      window.scrollTo({ top: 0 });
    } catch {
      update({
        participants: suggest(s.question, s.category, s.lang, participantCount),
        stage: "assemble",
      });
      setNotice(
        t(
          "AI matching was unavailable, so the app used the curated matching rules. You can still change any seat.",
          "تعذر الاختيار بالذكاء الاصطناعي، لذلك استخدم التطبيق قواعد الاختيار المنسقة. لا يزال بإمكانك تغيير أي مقعد.",
        ),
      );
      window.scrollTo({ top: 0 });
    } finally {
      setAssembling(false);
    }
  };
  const start = () => {
    if (!account) return;
    const available = account.usage.remaining;
    setRemaining(available);
    if (!available) {
      setError(
        t(
          "You have used both discussions in the current 24-hour window. Please return when one becomes available.",
          "استخدمت النقاشين المتاحين خلال نافذة 24 ساعة الحالية. عد عندما يتاح أحدهما.",
        ),
      );
      return;
    }
    stop();
    const names = s.participants
      .map((p) => nameOf(p, s.lang))
      .join(ar ? "، " : ", ");
    update({
      stage: "discuss",
      messages: [
        {
          id: crypto.randomUUID(),
          type: "moderator",
          name: t("Your moderator", "الميسّر"),
          text: t(
            `Welcome to the table. Our question: ${s.question}\n\nJoining us: ${names}. Our aim is to ${goals.find((g) => g[0] === s.goal)?.[1].toLowerCase()}. We will examine assumptions, invite disagreement, and look for a useful next step. You can guide us at any time.`,
            `مرحباً بكم. سؤالنا: ${s.question}\n\nيشاركنا: ${names}. هدفنا: ${goals.find((g) => g[0] === s.goal)?.[2]}. سنفحص الافتراضات ونرحب بالاختلاف ونبحث عن خطوة مفيدة. يمكنك توجيه الحوار في أي وقت.`,
          ),
        },
      ],
      turn: 0,
      queue: [],
      synthesis: "",
      synthesisAt: 0,
      usageCharged: false,
    });
    window.scrollTo({ top: 0 });
  };
  const generate = async (
    action: "contribution" | "synthesis",
    retry = false,
    snapshot?: Session,
  ) => {
    if (lock.current) return;
    const snap = snapshot || current.current;
    if (snap.messages.length >= 210) {
      setError(
        t(
          "Session limit reached. Export your discussion and begin a new one.",
          "وصلت الجلسة إلى حدها. صدّر النقاش وابدأ جلسة جديدة.",
        ),
      );
      return;
    }
    if (
      action === "contribution" &&
      !snap.usageCharged &&
      snap.turn === 0 &&
      account &&
      account.usage.remaining === 0
    ) {
      setRemaining(0);
      setError(
        t(
          "No discussions remain in the current 24-hour window.",
          "لا توجد نقاشات متبقية خلال نافذة 24 ساعة الحالية.",
        ),
      );
      return;
    }
    lock.current = true;
    setBusy(true);
    setError("");
    lastAction.current = action;
    const token = ++epoch.current;
    const ctrl = new AbortController();
    flight.current = ctrl;
    const timeout = setTimeout(
      () => ctrl.abort(),
      action === "synthesis" ? 60000 : 75000,
    );
    const seat = nextSpeaker(snap);
    if (action === "contribution") setSpeaking(seat);
    else setAutoplay(false);
    if (!retry || !retryId.current) retryId.current = crypto.randomUUID();
    const requestId = retryId.current;
    try {
      const r = await fetch("/api/discuss", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: ctrl.signal,
        body: JSON.stringify({ session: snap, action, requestId }),
      });
      const data = (await r.json()) as {
        text: string;
        mode: string;
        error?: string;
      };
      if (!r.ok) throw new Error(data.error || "GENERATION_FAILED");
      if (token !== epoch.current) return;
      if (typeof data.text !== "string" || !data.text.trim())
        throw new Error("EMPTY_RESPONSE");
      setMode(data.mode);
      if (action === "synthesis") {
        setS((v) => ({
          ...v,
          synthesis: data.text,
          synthesisAt: v.messages.length,
        }));
        setShowSynthesis(true);
      } else {
        const p = snap.participants[seat];
        let charged = snap.usageCharged || snap.turn > 0;
        if (!charged && account) {
          try {
            const usage = await consumeDiscussion();
            charged = true;
            setRemaining(usage.remaining);
            setAccount((value) => (value ? { ...value, usage } : value));
          } catch {
            throw new Error("NO_DISCUSSIONS");
          }
        }
        setS((v) =>
          v.messages.some((m) => m.id === requestId)
            ? v
            : {
                ...v,
                usageCharged: charged,
                turn: v.turn + 1,
                queue: v.queue[0] === p.id ? v.queue.slice(1) : v.queue,
                messages: [
                  ...v.messages,
                  {
                    id: requestId,
                    type: "participant",
                    name: nameOf(p, snap.lang),
                    participantId: p.id,
                    seat,
                    text: data.text,
                    label: kindLabel(p, snap.lang),
                    mode: data.mode,
                  },
                ],
              },
        );
      }
      retryId.current = "";
    } catch (e) {
      if (token !== epoch.current) return;
      setAutoplay(false);
      const code = (e as Error).message;
      const texts: Record<string, string> = {
        KEY_INVALID: t(
          "Kimi rejected the server key. Update it before retrying.",
          "رفض Kimi مفتاح الخادم. حدّثه قبل إعادة المحاولة.",
        ),
        RATE_LIMIT: t(
          "Kimi is busy or the rate limit was reached. Wait a moment, then retry.",
          "Kimi مشغول أو تم بلوغ حد الطلبات. انتظر قليلاً ثم أعد المحاولة.",
        ),
        BALANCE: t(
          "Check the API account balance, then retry.",
          "تحقق من رصيد حساب API ثم أعد المحاولة.",
        ),
        INTERRUPTED: t(
          "The response was interrupted. Nothing was added. Retry when ready.",
          "انقطعت الاستجابة ولم تُضف مساهمة. أعد المحاولة عندما تكون جاهزاً.",
        ),
      };
      setError(
        texts[code] ||
          t(
            "Could not finish this response. Your discussion is safe; please retry.",
            "تعذر إكمال الاستجابة. نقاشك محفوظ؛ أعد المحاولة.",
          ),
      );
    } finally {
      clearTimeout(timeout);
      if (token === epoch.current) {
        lock.current = false;
        flight.current = null;
        setBusy(false);
        setSpeaking(-1);
      }
    }
  };
  useEffect(() => {
    if (!autoplay || busy || s.stage !== "discuss") return;
    if (s.turn >= s.rounds * participantCount) {
      setAutoplay(false);
      return;
    }
    const id = setTimeout(() => void generate("contribution"), 3000);
    return () => clearTimeout(id);
  }, [autoplay, busy, s.turn, s.stage, s.rounds, participantCount]);
  const intervene = (text = host, inviteResponse = true) => {
    if (!text.trim()) return;
    stop();
    const snap = current.current;
    const directs =
      target === "all"
        ? []
        : [
            target,
            ...(debateWith && debateWith !== target ? [debateWith] : []),
          ];
    const addressed = directs
      .map((id) => snap.participants.find((p) => p.id === id))
      .filter(Boolean) as Profile[];
    const prefix = addressed.length
      ? (addressed.length === 2
          ? t("Debate: ", "نقاش بين: ")
          : t("To: ", "إلى: ")) +
        addressed.map((p) => nameOf(p, snap.lang)).join(ar ? " و " : " & ") +
        "\n"
      : "";
    const next = {
      ...snap,
      queue: directs,
      messages: [
        ...snap.messages,
        {
          id: crypto.randomUUID(),
          type: "host" as const,
          name: t("You · host", "أنت · المضيف"),
          text: prefix + text.trim(),
        },
      ],
    };
    current.current = next;
    setS(next);
    setHost("");
    setError("");
    retryId.current = "";
    if (inviteResponse) {
      setNotice("");
      queueMicrotask(() => void generate("contribution", false, next));
    } else
      setNotice(
        t(
          "Guidance added to the conversation.",
          "تمت إضافة التوجيه إلى الحوار.",
        ),
      );
  };
  const exportText = (onlySynthesis = false) =>
    `${t("The Council", "المجلس")}\n${s.question}\n\n${t("AI simulations and generic perspectives; no represented person participated or endorsed this conversation.", "محاكاة بالذكاء الاصطناعي ومنظورات عامة؛ لم تشارك الشخصيات الممثلة فعلياً ولم تؤيد الحوار.")}\n\n${onlySynthesis ? "" : s.messages.map((m) => `${m.name}${m.mode === "demo" ? t(" [SCRIPTED DEMO]", " [مثال مكتوب]") : ""}\n${m.text}`).join("\n\n— — —\n\n")}\n\n${s.synthesis ? `${s.synthesisAt < s.messages.length ? t("[Synthesis reflects an earlier point in the discussion]", "[الخلاصة تعكس مرحلة سابقة من النقاش]") : ""}\n${s.synthesis}` : ""}`;
  const download = (only = false) => {
    const url = URL.createObjectURL(
      new Blob(["\ufeff" + exportText(only)], {
        type: "text/plain;charset=utf-8",
      }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = only ? "council-synthesis.txt" : "council-transcript.txt";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const copy = async (only = false) => {
    try {
      await navigator.clipboard.writeText(exportText(only));
      setNotice(t("Copied to clipboard.", "تم النسخ."));
    } catch {
      setNotice(
        t(
          "Clipboard unavailable. Use Download instead.",
          "الحافظة غير متاحة. استخدم التنزيل.",
        ),
      );
    }
  };
  const saveCustom = () => {
    if (!draft.name.trim() || !draft.perspective.trim()) return;
    const p: Profile = {
      id: editingId || "custom-" + crypto.randomUUID(),
      name: draft.name,
      ar: draft.name,
      role: t("Your custom perspective", "منظورك المخصص"),
      roleAr: "منظور مخصص",
      group: "custom",
      kind: "custom",
      expertise: draft.background,
      expertiseAr: draft.background,
      priorities: draft.priorities || draft.perspective,
      prioritiesAr: draft.priorities || draft.perspective,
      tags: [],
      background: draft.background,
      perspective: draft.perspective,
    };
    setS((v) => ({
      ...v,
      custom: [...v.custom.filter((x) => x.id !== p.id), p],
    }));
    replace(p);
  };
  const resetDiscussionUi = () => {
    setError("");
    setHost("");
    setTarget("all");
    setDebateWith("");
    setShowSynthesis(false);
    setSelected(null);
    setCustomForm(false);
    setEditingId("");
  };
  const startNewDiscussion = () => {
    stop();
    const fresh = initialSession();
    fresh.lang = s.lang;
    const id = crypto.randomUUID();
    setActiveId(id);
    setS(fresh);
    setShowDashboard(false);
    resetDiscussionUi();
    try {
      localStorage.setItem(ACTIVE_STORAGE, id);
      localStorage.setItem(STORAGE, JSON.stringify(fresh));
    } catch {}
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const openDiscussion = (item: DiscussionRecord) => {
    stop();
    setActiveId(item.id);
    setS(item.session);
    setShowDashboard(false);
    resetDiscussionUi();
    try {
      localStorage.setItem(ACTIVE_STORAGE, item.id);
      localStorage.setItem(STORAGE, JSON.stringify(item.session));
    } catch {}
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const removeDiscussion = (id: string) => {
    fetch(`/api/discussions?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
    }).catch(() => undefined);
    setHistory((previous) => {
      const next = previous.filter((item) => item.id !== id);
      try {
        localStorage.setItem(HISTORY_STORAGE, JSON.stringify(next));
      } catch {}
      return next;
    });
    if (id === activeId) {
      const fresh = initialSession();
      fresh.lang = s.lang;
      const nextId = crypto.randomUUID();
      setS(fresh);
      setActiveId(nextId);
      try {
        localStorage.setItem(STORAGE, JSON.stringify(fresh));
        localStorage.setItem(ACTIVE_STORAGE, nextId);
      } catch {}
    }
  };
  const deleteSession = () => {
    stop();
    removeDiscussion(activeId);
    setDeleteOpen(false);
    resetDiscussionUi();
    setShowDashboard(true);
    setNotice(
      t(
        "The saved conversation was deleted from your account.",
        "تم حذف المحادثة المحفوظة من حسابك.",
      ),
    );
  };
  useEffect(() => {
    const context = (
      document as unknown as {
        modelContext?: {
          registerTool: (tool: unknown, options: unknown) => void;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    try {
      context.registerTool(
        {
          name: "read_council_session",
          description:
            "Read the current question, stage, participants and contribution count.",
          inputSchema: {
            type: "object",
            properties: {},
            additionalProperties: false,
          },
          annotations: { readOnlyHint: true, untrustedContentHint: true },
          execute: () => ({
            question: current.current.question,
            stage: current.current.stage,
            participants: current.current.participants.map((p) => p.name),
            contributions: current.current.turn,
          }),
        },
        { signal: lifecycle.signal },
      );
      context.registerTool(
        {
          name: "stage_council_question",
          description:
            "Set a question and stage the selected number of suggestions for host review; does not begin discussion.",
          inputSchema: {
            type: "object",
            properties: {
              question: { type: "string", minLength: 1, maxLength: 2000 },
            },
            required: ["question"],
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false, untrustedContentHint: true },
          execute: (input: unknown) => {
            const q = (input as { question?: unknown })?.question;
            if (typeof q !== "string" || !q.trim() || q.length > 2000)
              throw Error("Invalid question");
            if (current.current.stage === "discuss")
              throw Error(
                "An active discussion must be deleted through the interface first",
              );
            stop();
            const updated = {
              ...current.current,
              question: q,
              participants: suggest(
                q,
                current.current.category,
                current.current.lang,
                current.current.participantCount ?? 5,
              ),
              stage: "assemble" as const,
            };
            current.current = updated;
            setS(updated);
            return {
              stage: "assemble",
              question: q,
              participants: updated.participants.map((p) => p.name),
            };
          },
        },
        { signal: lifecycle.signal },
      );
    } catch {}
    return () => lifecycle.abort();
  }, []);
  const people =
    s.participants.length === participantCount
      ? s.participants
      : suggest(
          s.question || "meaningful life",
          s.category || "philosophy",
          s.lang,
          participantCount,
        );
  const available = [...catalogue, ...s.custom].filter(
    (p) => group === "all" || p.group === group,
  );
  const dailySuggestions = dailyQuestionPool.length
    ? categories.slice(0, 5).map(([id], index) => {
        const choices = dailyQuestionPool.filter((row) => row[2] === id);
        return choices[(dayKey + index) % choices.length];
      }).filter(Boolean)
    : dailyQuestionSuggestions("", dayKey);
  const categorySuggestions = s.category
    ? dailyQuestionPool.filter((row) => row[2] === s.category).slice(0, 5)
    : [];
  const categoryName =
    categories.find(([id]) => id === s.category)?.[ar ? 2 : 1] || "";
  const errorsOrNotice = (
    <>
      {error && (
        <div role="alert" className="error">
          {error}
          <button
            className="quiet"
            disabled={busy}
            onClick={() => generate(lastAction.current, true)}
          >
            <RotateCcw size={15} />
            {t("Retry", "إعادة المحاولة")}
          </button>
        </div>
      )}
      {notice && (
        <div role="status" className="notice">
          {notice}
          <button
            aria-label={t("Dismiss", "إغلاق")}
            onClick={() => setNotice("")}
          >
            <X size={15} />
          </button>
        </div>
      )}
    </>
  );
  if (!authReady)
    return (
      <main className="auth-page brand-loading" dir={ar ? "rtl" : "ltr"}>
        <CouncilMark className="loading-mark" state="seating" />
        <strong>{t("The Council", "المجلس")}</strong>
        <span>{t("Preparing your council…", "جارٍ تجهيز المجلس…")}</span>
      </main>
    );
  if (!account)
    return (
      <AccountGate
        lang={s.lang}
        onLanguageChange={(lang) => update({ lang })}
        onSignedIn={async (value) => {
          setAccount(value);
          setRemaining(value.usage.remaining);
          const localItems = history.filter(
            (item) => item.owner === value.email,
          );
          for (const item of localItems)
            await saveAccountDiscussion(item).catch(() => undefined);
          setHistory(await loadAccountDiscussions());
          setShowDashboard(true);
        }}
      />
    );
  return (
    <main dir={ar ? "rtl" : "ltr"}>
      <header className="topbar">
        <div className="brand-lockup">
          <a
            className="brand"
            href="/"
            onClick={(e) => {
              e.preventDefault();
              stop();
              setShowDashboard(true);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          >
            <span className="brand-icon-wrap">
              <CouncilMark className="brand-logo" state="rest" />
              <span className="brand-tooltip" role="tooltip">
                {t(
                  "Return to your council home",
                  "العودة إلى الصفحة الرئيسية للمجلس",
                )}
              </span>
            </span>
            <span>{t("The Council", "المجلس")}</span>
          </a>
          <span className="brand-divider" aria-hidden="true" />
          <div className="owner-brand">
            <span>{t("An Emad Hanna product", "منتج من شركة عماد حنا")}</span>
            <img
              src="/emad-hanna-company-logo.png"
              alt={t("The Council", "المجلس")}
            />
          </div>
        </div>
        <nav className="header-actions">
          <button
            className="quiet header-new-discussion"
            onClick={startNewDiscussion}
          >
            <Plus size={16} />
            <span className="desktop-label">
              {t("New discussion", "نقاش جديد")}
            </span>
          </button>
          <button
            className="quiet"
            onClick={() => {
              stop();
              update({ lang: ar ? "en" : "ar" });
              setError("");
            }}
          >
            <Globe2 size={17} />
            {ar ? "English" : "العربية"}
          </button>
          <AccountMenu
            account={account}
            lang={s.lang}
            onAccountChange={(value) => {
              setAccount(value);
              setRemaining(value.usage.remaining);
            }}
            onLanguageChange={(lang) => update({ lang })}
            onSignOut={async () => {
              stop();
              await signOutBrowserAccount();
              setAccount(null);
            }}
          />
          {!showDashboard && s.stage !== "start" && (
            <button
              className="quiet"
              aria-label={t("Delete session", "حذف الجلسة")}
              onClick={() => setDeleteOpen(true)}
            >
              <Trash2 size={16} />
            </button>
          )}
        </nav>
      </header>
      <div className="mode-strip">
        <span className={"status-dot " + (mode === "live" ? "live" : "")} />
        {mode === "live"
          ? t("Live AI · powered by Kimi", "ذكاء اصطناعي مباشر · بدعم Kimi")
          : mode === "checking"
            ? t("Checking AI connection…", "جارٍ فحص الاتصال…")
            : mode === "offline"
              ? t(
                  "Connection unavailable · retry when ready",
                  "الاتصال غير متاح · أعد المحاولة لاحقاً",
                )
              : t(
                  "Demonstration mode · scripted examples, not live AI",
                  "وضع توضيحي · أمثلة مكتوبة وليست ذكاءً اصطناعياً مباشراً",
                )}
        <button onClick={() => setShowInfo(true)}>
          {t("Details", "التفاصيل")}
        </button>
      </div>
      {showDashboard ? (
        <DiscussionDashboard
          lang={s.lang}
          items={history.filter((item) => item.owner === account.email)}
          onStart={startNewDiscussion}
          onOpen={openDiscussion}
          onDelete={removeDiscussion}
          onRename={(id, title) => {
            setHistory((previous) => {
              const next = previous.map((item) =>
                item.id === id
                  ? { ...item, title, updatedAt: Date.now() }
                  : item,
              );
              const changed = next.find((item) => item.id === id);
              if (changed)
                saveAccountDiscussion(changed).catch(() => undefined);
              localStorage.setItem(HISTORY_STORAGE, JSON.stringify(next));
              return next;
            });
          }}
        />
      ) : s.stage === "start" ? (
        <>
          <div className="start-layout">
            <section className="intro">
              <h1 className="hero-title">
                {t(
                  "A little space for big ideas",
                  "مساحة هادئة للأفكار الكبيرة",
                )}
              </h1>
              <p className="lead">
                {t(
                  "Different minds. A shared question. See what a thoughtful conversation can open up.",
                  "عقول مختلفة. سؤال مشترك. اكتشف ما يمكن أن يفتحه حوار متأنٍ.",
                )}
              </p>
              <div className="participant-picker">
                <div>
                  <span className="field-label">
                    {t("Number of participants", "عدد المشاركين")}
                  </span>
                  <small>
                    {t(
                      "Choose the size of this conversation.",
                      "اختر عدد المشاركين بالحوار",
                    )}
                  </small>
                </div>
                <div
                  className="participant-options"
                  role="group"
                  aria-label={t("Number of participants", "عدد المشاركين")}
                >
                  {[2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      className={participantCount === n ? "active" : ""}
                      aria-pressed={participantCount === n}
                      onClick={() =>
                        update({
                          participantCount: n,
                          participants: [],
                          messages: [],
                          turn: 0,
                          queue: [],
                          synthesis: "",
                          synthesisAt: 0,
                        })
                      }
                    >
                      <Users size={16} />
                      <b>{n}</b>
                    </button>
                  ))}
                </div>
              </div>
              <span className="field-label">
                {t(
                  "Choose a topic to discover questions",
                  "اختر موضوعاً لاكتشاف أسئلة",
                )}
              </span>
              <div
                className="chips topic-chips"
                aria-label={t("Topic category", "تصنيف الموضوع")}
              >
                {categories.map(([id, en, arabic]) => (
                  <button
                    key={id}
                    className={"chip " + (s.category === id ? "active" : "")}
                    aria-pressed={s.category === id}
                    onClick={() =>
                      update({ category: s.category === id ? "" : id })
                    }
                  >
                    {ar ? arabic : en}
                  </button>
                ))}
              </div>
              {categorySuggestions.length > 0 && (
                <div className="category-question-panel">
                  <div className="category-question-head">
                    <span>
                      <Sparkles size={15} />
                      {t("Five ideas for ", "خمسة أسئلة حول ")}
                      {categoryName}
                    </span>
                    <small>{t("Fresh each day", "تتجدد يومياً")}</small>
                  </div>
                  <div className="category-question-list">
                    {categorySuggestions.map(([en, arabic, cat], i) => (
                      <button
                        key={cat + "-" + en}
                        onClick={() =>
                          update({ question: ar ? arabic : en, category: cat })
                        }
                      >
                        <span>{i + 1}</span>
                        <b>{ar ? arabic : en}</b>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <label className="field-label question-label" htmlFor="question">
                {t("What would you like to discuss?", "ما الذي تود مناقشته؟")}
              </label>
              <textarea
                id="question"
                maxLength={2000}
                value={s.question}
                onChange={(e) => update({ question: e.target.value })}
                placeholder={
                  dailySuggestions[0]?.[ar ? 1 : 0] ||
                  t(
                    "Write the question you want the table to explore…",
                    "اكتب السؤال الذي تريد من الطاولة استكشافه…",
                  )
                }
              />
              <details className="context">
                <summary>
                  <Plus size={15} />
                  {t("Add context or constraints", "إضافة سياق أو قيود")}
                  <small>{t("optional", "اختياري")}</small>
                </summary>
                <label className="sr-only" htmlFor="context">
                  {t("Background and constraints", "الخلفية والقيود")}
                </label>
                <textarea
                  id="context"
                  maxLength={8000}
                  value={s.context}
                  onChange={(e) => update({ context: e.target.value })}
                  placeholder={t(
                    "Who is affected? What matters? What are the limits?",
                    "من المتأثر؟ ما المهم؟ ما القيود؟",
                  )}
                />
              </details>
              <div className="form-grid">
                <Choice
                  label={t("I’d like to…", "أود أن…")}
                  value={s.goal}
                  options={opts(goals)}
                  onChange={(v) => update({ goal: v })}
                />
                <Choice
                  label={t("Discussion language", "لغة النقاش")}
                  value={s.lang}
                  options={[
                    ["en", "English"],
                    ["ar", "العربية"],
                  ]}
                  onChange={(v) => update({ lang: v as Lang })}
                />
              </div>
              <button
                className="primary full"
                disabled={!ready || !s.question.trim() || assembling}
                onClick={() => void assemble()}
              >
                {assembling ? (
                  <LoaderCircle size={17} className="spin" />
                ) : (
                  <Sparkles size={17} />
                )}{" "}
                {assembling
                  ? t(
                      "Finding the best perspectives…",
                      "جارٍ اختيار أنسب المنظورات…",
                    )
                  : t("Assemble your table", "شكّل طاولتك")}{" "}
                {!assembling && <ArrowRight size={18} />}
              </button>
              <p className="subnote">
                <ShieldCheck size={13} />
                {t(
                  "Your conversation stays in this browser. You’re the host.",
                  "محادثتك محفوظة في هذا المتصفح. أنت المضيف.",
                )}
              </p>
              {errorsOrNotice}
            </section>
            <section className="table-preview">
              <Table
                people={people}
                lang={s.lang}
                onSelect={() => {
                  if (s.question.trim()) assemble();
                  else
                    setNotice(
                      t(
                        "Begin with a question to choose your participants.",
                        "ابدأ بسؤال لاختيار المشاركين.",
                      ),
                    );
                }}
                speaking={-1}
                selected={null}
                stage="start"
              />
              <p className="caption">
                {t(
                  "The best questions deserve more than one answer.",
                  "أفضل الأسئلة تستحق أكثر من إجابة.",
                )}
              </p>
              <div className="try-questions">
                <span className="eyebrow">
                  {t("FIVE FRESH QUESTIONS TODAY", "خمسة أسئلة جديدة اليوم")}
                </span>
                <small className="daily-note">
                  {t(
                    "A new mix appears every day.",
                    "تظهر مجموعة جديدة كل يوم.",
                  )}
                </small>
                {dailySuggestions.map(([en, arabic, cat]) => (
                  <button
                    key={en}
                    onClick={() =>
                      update({ question: ar ? arabic : en, category: cat })
                    }
                  >
                    <span>{ar ? arabic : en}</span>
                    <ChevronRight size={17} />
                  </button>
                ))}
              </div>
            </section>
          </div>
        </>
      ) : s.stage === "assemble" ? (
        <div className="workspace">
          <div className="section-heading">
            <div>
              <button
                className="quiet"
                onClick={() => update({ stage: "start" })}
              >
                <ArrowLeft size={15} />
                {t("Your question", "سؤالك")}
              </button>
              <h2>
                {t("A table with room for difference.", "طاولة تتسع للاختلاف.")}
              </h2>
              <p className="question-line">{s.question}</p>
            </div>
            <span className="step-pill">
              {t("02 / ASSEMBLE", "02 / اختيار المشاركين")}
            </span>
          </div>
          <div className="assembly-grid">
            <section>
              <Table
                people={people}
                lang={s.lang}
                onSelect={(i) => {
                  setSelected(i);
                  setCustomForm(false);
                }}
                speaking={-1}
                selected={selected}
                stage="assemble"
              />
              <p className="caption">
                {t(
                  "Select any chair to make this table your own.",
                  "اختر أي مقعد لتخصص طاولتك.",
                )}
              </p>
              <div className="simulation-note">
                <BookOpen size={19} />
                <p>
                  {t(
                    "Inspired perspectives, honestly represented. Real people have not participated or endorsed this discussion.",
                    "منظورات مستوحاة وممثلة بوضوح. لم يشارك الأشخاص الحقيقيون في هذا النقاش ولم يؤيدوه.",
                  )}
                </p>
              </div>
            </section>
            <section className="suggestions">
              <span className="eyebrow">
                {t("SUGGESTED FOR YOUR QUESTION", "مقترح لسؤالك")}
              </span>
              <p className="muted">
                {ar
                  ? `${people.length} منظورات تجمع الصلة والاختلاف. اعتمد الطاولة أو غيّر أي مقعد.`
                  : `${people.length} lenses, chosen for relevance and contrast. Keep the table or change any seat.`}
              </p>
              {people.map((p, i) => (
                <button
                  className="profile-row"
                  key={p.id}
                  onClick={() => {
                    setSelected(i);
                    setCustomForm(false);
                  }}
                >
                  <span className={"avatar color-" + i}>
                    <PerspectiveIcon p={p} />
                  </span>
                  <span>
                    <b>
                      {i + 1}. {nameOf(p, s.lang)}
                    </b>
                    <small>
                      {kindLabel(p, s.lang)} · {ar ? p.roleAr : p.role}
                    </small>
                    <p>
                      <strong>{t("Why selected: ", "سبب الاختيار: ")}</strong>
                      {p.reason || (ar ? p.prioritiesAr : p.priorities)}
                    </p>
                  </span>
                  <ChevronRight size={17} />
                </button>
              ))}
              <div className="settings">
                <div className="form-grid">
                  <Choice
                    label={t("Discussion style", "أسلوب النقاش")}
                    value={s.style}
                    options={opts([
                      ["balanced", "Balanced", "متوازن"],
                      ["collaborative", "Collaborative", "تعاوني"],
                      ["critical", "Critical debate", "نقاش نقدي"],
                      ["socratic", "Socratic inquiry", "تساؤل سقراطي"],
                    ])}
                    onChange={(v) => update({ style: v })}
                  />
                  <Choice
                    label={t("Contribution length", "طول المساهمة")}
                    value={s.length}
                    options={opts([
                      ["short", "Short", "قصير"],
                      ["medium", "Medium", "متوسط"],
                      ["detailed", "Detailed", "مفصل"],
                    ])}
                    onChange={(v) => update({ length: v })}
                  />
                  <Choice
                    label={t("Approximate rounds", "عدد الجولات التقريبي")}
                    value={String(s.rounds)}
                    options={[1, 2, 3, 5, 8, 10].map((n) => [
                      String(n),
                      `${n} ${t("rounds", "جولات")}`,
                    ])}
                    onChange={(v) => update({ rounds: Number(v) })}
                  />
                  <Choice
                    label={t("Religious perspectives", "المنظورات الدينية")}
                    value={s.respectful ? "tradition" : "imagined"}
                    options={opts([
                      [
                        "tradition",
                        "Respectful · tradition-based",
                        "احترام · منظور تراثي",
                      ],
                      [
                        "imagined",
                        "Labeled imagined interpretation",
                        "تفسير متخيل مع توضيح",
                      ],
                    ])}
                    onChange={(v) => update({ respectful: v === "tradition" })}
                  />
                </div>
              </div>
              <button className="primary full" onClick={start}>
                <Check size={18} />
                {t(
                  "Accept table & enter discussion",
                  "اعتمد الطاولة وادخل النقاش",
                )}
                <ArrowRight size={18} />
              </button>
              <p className="quota-note">
                {t(
                  "Your discussion is counted only after the first AI contribution succeeds.",
                  "يُحتسب النقاش فقط بعد نجاح أول مساهمة من الذكاء الاصطناعي.",
                )}
              </p>
              {errorsOrNotice}
            </section>
          </div>
        </div>
      ) : (
        <div className="discussion-layout">
          <aside className="table-sidebar">
            <span className="eyebrow">{t("YOUR QUESTION", "سؤالك")}</span>
            <h2>{s.question}</h2>
            <Table
              people={people}
              lang={s.lang}
              onSelect={(i) => {
                stop();
                setSelected(i);
                setCustomForm(false);
              }}
              speaking={speaking}
              selected={selected}
              turn={Math.min(s.turn, s.rounds * participantCount - 1)}
              stage="discuss"
            />
            <p className="caption">
              {ar
                ? `${people.length} منظورات. وأنت توجه الحوار.`
                : `${people.length} perspectives. You guide the conversation.`}
            </p>
            <div className="session-facts">
              <span>
                <Users size={15} />
                {t("You are the host", "أنت المضيف")}
              </span>
              <span>
                {t("Round", "الجولة")}{" "}
                {Math.min(Math.floor(s.turn / participantCount) + 1, s.rounds)}{" "}
                / {s.rounds}
              </span>
            </div>
            <div className="sidebar-actions">
              <button
                className="outline"
                onClick={() => generate("synthesis")}
                disabled={busy}
              >
                <Sparkles size={16} />
                {t("Create a synthesis", "إنشاء خلاصة")}
              </button>
              {s.synthesis && (
                <button
                  className="quiet"
                  onClick={() => setShowSynthesis(true)}
                >
                  {t("Read saved synthesis", "قراءة الخلاصة المحفوظة")}
                </button>
              )}
              <div className="inline-actions">
                <button className="quiet" onClick={() => download()}>
                  <Download size={15} />
                  {t("Transcript", "النص الكامل")}
                </button>
                <button className="quiet" onClick={() => copy()}>
                  <Copy size={15} />
                  {t("Copy", "نسخ")}
                </button>
              </div>
            </div>
            <p className="subnote">
              {t(
                "AI-simulated perspectives. No real participant or endorsement. Factual claims need verification.",
                "منظورات تحاكيها الآلة. لا مشاركة أو تأييد فعلي. الادعاءات الواقعية تحتاج إلى تحقق.",
              )}
            </p>
          </aside>
          <section className="conversation">
            <div className="conversation-header">
              <span>
                <MessageCircle size={18} />
                {t("The conversation", "الحوار")}
              </span>
              <span className="tiny">
                {s.turn} {t("contributions", "مساهمات")}
              </span>
            </div>
            <div
              className="messages"
              role="log"
              aria-label={t("Discussion transcript", "نص النقاش")}
              aria-live="polite"
            >
              {s.messages.map((m) => (
                <article key={m.id} className={"message " + m.type}>
                  <div className="message-head">
                    {m.type === "participant" && (
                      <span className={"mini-avatar color-" + m.seat}>
                        {m.seat !== undefined && people[m.seat] ? (
                          <PerspectiveIcon p={people[m.seat]} size={16} />
                        ) : (
                          <UserRound size={16} aria-hidden="true" />
                        )}
                      </span>
                    )}
                    <b>{m.name}</b>
                    <small>
                      {m.mode === "demo"
                        ? t("SCRIPTED DEMO", "مثال مكتوب")
                        : m.label || ""}
                    </small>
                  </div>
                  <div className="message-content">
                    <FormattedText text={m.text} />
                  </div>
                </article>
              ))}
              {busy && (
                <div className="thinking" role="status">
                  <LoaderCircle size={17} className="spin" />
                  <span>
                    {busyLabel}
                    <small>{busySeconds}s</small>
                  </span>
                </div>
              )}
              {!s.turn && !busy && (
                <p className="begin-hint">
                  {t(
                    "Ready when you are. Invite the first contribution below.",
                    "عندما تكون جاهزاً، اطلب المساهمة الأولى أدناه.",
                  )}
                </p>
              )}
              <div ref={end} />
            </div>
            <div className="conversation-controls">
              {errorsOrNotice}
              <div className="progression">
                <button
                  className="primary"
                  disabled={busy}
                  onClick={() => generate("contribution")}
                >
                  <Play size={16} />
                  {t("Next contribution", "المساهمة التالية")}
                </button>
                <button
                  className="outline"
                  onClick={() =>
                    autoplay || busy ? stop() : setAutoplay(true)
                  }
                >
                  {autoplay || busy ? <Pause size={16} /> : <Play size={16} />}{" "}
                  {autoplay || busy
                    ? t("Pause", "إيقاف مؤقت")
                    : t("Autoplay", "تشغيل تلقائي")}
                </button>
              </div>
              {s.turn >= s.rounds * participantCount && (
                <p className="round-complete">
                  {t(
                    "Planned rounds complete. Create a synthesis or continue manually.",
                    "اكتملت الجولات المحددة. أنشئ خلاصة أو تابع يدوياً.",
                  )}
                </p>
              )}
              <div className="quick-actions">
                {[
                  ["Who disagrees?", "من يعترض؟"],
                  ["Explain more simply.", "اشرح ببساطة أكبر."],
                  ["What are we missing?", "ما الذي نغفله؟"],
                  [
                    "Test this against a real example.",
                    "اختبر هذا بمثال واقعي.",
                  ],
                  ["Summarize so far.", "لخّص ما وصلنا إليه."],
                  ["Develop a proposal.", "طوّر مقترحاً."],
                ].map(([en, arabic]) => (
                  <button key={en} onClick={() => intervene(ar ? arabic : en)}>
                    {ar ? arabic : en}
                  </button>
                ))}
              </div>
              <div className="host-box">
                <div className="address-row">
                  <Choice
                    label={t("Address", "وجّه الكلام إلى")}
                    value={target}
                    options={[
                      ["all", t("Whole table", "الطاولة كلها")],
                      ...people.map((p) => [p.id, nameOf(p, s.lang)]),
                    ]}
                    onChange={(v) => {
                      setTarget(v);
                      setDebateWith("");
                    }}
                  />
                  {target !== "all" && (
                    <Choice
                      label={t("Invite a debate with", "دعوة لنقاش مع")}
                      value={debateWith}
                      options={[
                        ["", t("No second participant", "دون مشارك ثانٍ")],
                        ...people
                          .filter((p) => p.id !== target)
                          .map((p) => [p.id, nameOf(p, s.lang)]),
                      ]}
                      onChange={setDebateWith}
                    />
                  )}
                </div>
                <label className="sr-only" htmlFor="host">
                  {t(
                    "Add your perspective or guide the discussion…",
                    "أضف منظورك أو وجّه النقاش…",
                  )}
                </label>
                <textarea
                  id="host"
                  maxLength={5000}
                  value={host}
                  onChange={(e) => {
                    if (autoplay) stop();
                    setHost(e.target.value);
                  }}
                  placeholder={t(
                    "Add your perspective or guide the discussion…",
                    "أضف منظورك أو وجّه النقاش…",
                  )}
                  onKeyDown={(e) => {
                    if ((e.ctrlKey || e.metaKey) && e.key === "Enter")
                      intervene();
                  }}
                />
                <div className="host-footer">
                  <small>
                    {t(
                      "Challenge, clarify, add a constraint, or move toward a conclusion.",
                      "اعترض أو استوضح أو أضف قيداً أو وجّه نحو نتيجة.",
                    )}
                  </small>
                  <button
                    className="primary"
                    disabled={!host.trim()}
                    onClick={() => intervene()}
                    aria-label={t("Send guidance", "إرسال التوجيه")}
                  >
                    <Send size={17} />
                  </button>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}
      <footer className="footer">
        <div className="footer-identity">
          <CouncilMark className="loading-mark" state="rest" />
        </div>
        <button
          className="quiet footer-about"
          onClick={() => setShowInfo(true)}
        >
          <ShieldCheck size={14} />
          <span>
            <b>{t("About your table", "عن طاولتك")}</b>
            <small>
              {t(
                "Privacy & AI transparency",
                "الخصوصية وشفافية الذكاء الاصطناعي",
              )}
            </small>
          </span>
        </button>
      </footer>
      <>
        {selected !== null && !customForm && (
          <PersonaExplorer
            key={selected}
            seat={selected}
            people={people}
            lang={s.lang}
            question={s.question}
            onClose={() => setSelected(null)}
            onSeat={replace}
            onCustom={() => {
              setEditingId("");
              setDraft({
                name: "",
                background: "",
                perspective: "",
                priorities: "",
              });
              setCustomForm(true);
            }}
          />
        )}
      </>
      <Dialog
        open={selected !== null && customForm}
        onOpenChange={(open) => {
          if (!open) {
            setSelected(null);
            setCustomForm(false);
          }
        }}
      >
        <DialogContent
          className="rt-dialog"
          showCloseButton={false}
          dir={ar ? "rtl" : "ltr"}
        >
          <DialogClose className="dialog-x" aria-label={t("Close", "إغلاق")}>
            <X size={20} />
          </DialogClose>
          <DialogTitle>
            {t("Choose a perspective", "اختر منظوراً")} ·{" "}
            {selected !== null ? selected + 1 : ""}
          </DialogTitle>
          <DialogDescription>
            {t(
              "Search by name or expertise. Each chair holds a distinct perspective.",
              "ابحث بالاسم أو الخبرة. لكل مقعد منظور مختلف.",
            )}
          </DialogDescription>
          {selected !== null && (
            <div className="selected-profile">
              <b>{nameOf(people[selected], s.lang)}</b>
              <small>{kindLabel(people[selected], s.lang)}</small>
              <p>
                {ar ? people[selected].expertiseAr : people[selected].expertise}
              </p>
              <p>
                <strong>
                  {t("Why this perspective: ", "لماذا هذا المنظور: ")}
                </strong>
                {ar
                  ? people[selected].prioritiesAr
                  : people[selected].priorities}
              </p>
              {people[selected].kind === "custom" && (
                <button
                  className="quiet"
                  onClick={() => {
                    const p = people[selected];
                    setEditingId(p.id);
                    setDraft({
                      name: p.name,
                      background: p.background || "",
                      perspective: p.perspective || "",
                      priorities: p.priorities,
                    });
                    setCustomForm(true);
                  }}
                >
                  {t("Edit this custom profile", "تعديل هذه الشخصية")}
                </button>
              )}
            </div>
          )}
          {!customForm ? (
            <>
              <Choice
                label={t("Catalogue", "الدليل")}
                value={group}
                options={opts(groups)}
                onChange={setGroup}
              />
              <Combobox<Profile>
                items={available}
                itemToStringLabel={(p) =>
                  `${nameOf(p, s.lang)} · ${ar ? p.expertiseAr : p.expertise}`
                }
                onValueChange={(p) => {
                  if (p) replace(p);
                }}
              >
                <ComboboxInput
                  aria-label={t("Search participants", "البحث عن المشاركين")}
                  placeholder={t(
                    "Search names, roles, or expertise…",
                    "ابحث بالاسم أو الدور أو الخبرة…",
                  )}
                />
                <ComboboxContent
                  className="catalogue-popup"
                  dir={ar ? "rtl" : "ltr"}
                >
                  <ComboboxEmpty>
                    {t(
                      "No matching profiles. Create your own below.",
                      "لا توجد نتائج. أنشئ شخصية أدناه.",
                    )}
                  </ComboboxEmpty>
                  <ComboboxList>
                    {(p: Profile) => (
                      <ComboboxItem
                        key={p.id}
                        value={p}
                        disabled={people.some(
                          (x, i) => x.id === p.id && i !== selected,
                        )}
                      >
                        <div>
                          <b>{nameOf(p, s.lang)}</b>
                          <small>
                            {kindLabel(p, s.lang)} · {ar ? p.roleAr : p.role}
                          </small>
                          <p>{ar ? p.expertiseAr : p.expertise}</p>
                        </div>
                      </ComboboxItem>
                    )}
                  </ComboboxList>
                </ComboboxContent>
              </Combobox>
              <p className="tiny">
                {available.length}{" "}
                {t(
                  "profiles in this category. Open the search to browse.",
                  "شخصية في هذا التصنيف. افتح البحث للتصفح.",
                )}
              </p>
              <button
                className="outline"
                onClick={() => {
                  setEditingId("");
                  setDraft({
                    name: "",
                    background: "",
                    perspective: "",
                    priorities: "",
                  });
                  setCustomForm(true);
                }}
              >
                <Plus size={17} />
                {t("Create a custom profile", "إنشاء شخصية مخصصة")}
              </button>
            </>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                saveCustom();
              }}
              className="custom-form"
            >
              {(
                ["name", "background", "perspective", "priorities"] as const
              ).map((field, i) => (
                <label className="field-label" key={field}>
                  {
                    [
                      t("Name or role *", "الاسم أو الدور *"),
                      t("Background", "الخلفية"),
                      t("Perspective *", "المنظور *"),
                      t("Priorities", "الأولويات"),
                    ][i]
                  }
                  <textarea
                    required={field === "name" || field === "perspective"}
                    maxLength={field === "name" ? 80 : 1500}
                    value={draft[field]}
                    onChange={(e) =>
                      setDraft({ ...draft, [field]: e.target.value })
                    }
                  />
                </label>
              ))}
              <p className="tiny">
                {t(
                  "Fictional profiles only. No sensitive personal information is needed.",
                  "شخصيات خيالية فقط. لا حاجة إلى معلومات شخصية حساسة.",
                )}
              </p>
              <div className="inline-actions">
                <button
                  type="button"
                  className="quiet"
                  onClick={() => setCustomForm(false)}
                >
                  {t("Back", "رجوع")}
                </button>
                <button className="primary" type="submit">
                  {t("Save & seat profile", "احفظ وأضف إلى المقعد")}
                </button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={showSynthesis} onOpenChange={setShowSynthesis}>
        <DialogContent
          className="rt-dialog synthesis-dialog"
          showCloseButton={false}
          dir={ar ? "rtl" : "ltr"}
        >
          <DialogClose className="dialog-x" aria-label={t("Close", "إغلاق")}>
            <X size={20} />
          </DialogClose>
          <DialogTitle>
            {t("Where the conversation leads", "إلى أين يقودنا الحوار")}
          </DialogTitle>
          <DialogDescription>
            {t(
              "AI-generated analysis, never an endorsement by represented figures.",
              "تحليل مولد بالذكاء الاصطناعي وليس تأييداً من الشخصيات الممثلة.",
            )}
          </DialogDescription>
          {s.synthesisAt < s.messages.length && (
            <p className="notice">
              {t(
                "The conversation has moved on. Regenerate for an updated synthesis.",
                "تقدم الحوار. أعد التوليد للحصول على خلاصة محدثة.",
              )}
            </p>
          )}
          <div className="synthesis-text">{s.synthesis}</div>
          <div className="inline-actions">
            <button className="outline" onClick={() => download(true)}>
              <Download size={16} />
              {t("Download", "تنزيل")}
            </button>
            <button className="outline" onClick={() => copy(true)}>
              <Copy size={16} />
              {t("Copy", "نسخ")}
            </button>
            <button
              className="quiet"
              disabled={busy}
              onClick={() => {
                setShowSynthesis(false);
                generate("synthesis");
              }}
            >
              <RotateCcw size={16} />
              {t("Regenerate", "إعادة التوليد")}
            </button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={showInfo} onOpenChange={setShowInfo}>
        <DialogContent
          className="rt-dialog"
          showCloseButton={false}
          dir={ar ? "rtl" : "ltr"}
        >
          <DialogClose className="dialog-x" aria-label={t("Close", "إغلاق")}>
            <X size={20} />
          </DialogClose>
          <DialogTitle>
            {t("A little clarity about your table", "توضيح حول طاولتك")}
          </DialogTitle>
          <DialogDescription>
            {t(
              "Private by default. Honest about AI.",
              "الخصوصية افتراضياً. والوضوح بشأن الذكاء الاصطناعي.",
            )}
          </DialogDescription>
          <div className="info-copy">
            <h3>{t("Your conversation", "محادثتك")}</h3>
            <p>
              {t(
                "Your discussions are saved privately to your account so you can continue on another device. They are not public links. Use the discussion menu to delete a saved conversation; downloaded copies remain on your device.",
                "تُحفظ نقاشاتك بشكل خاص في حسابك لتتمكن من متابعتها على جهاز آخر. وهي ليست روابط عامة. استخدم قائمة النقاش لحذف المحادثة المحفوظة؛ وتبقى النسخ المنزلة على جهازك.",
              )}
            </p>
            <h3>{t("Account and daily limit", "الحساب والحد اليومي")}</h3>
            <p>
              {t(
                "Your account, profile, usage, and discussion history are synchronized securely across devices. Free accounts include two discussions in a rolling 24-hour window. Email verification and password recovery are not available yet.",
                "تتم مزامنة حسابك وملفك الشخصي واستخدامك وسجل نقاشاتك بأمان عبر الأجهزة. تتضمن الحسابات المجانية نقاشين ضمن نافذة متحركة مدتها 24 ساعة. لا يتوفر التحقق من البريد أو استعادة كلمة المرور بعد.",
              )}
            </p>
            <h3>{t("How generation works", "كيف يعمل التوليد")}</h3>
            <p>
              {t(
                "When Kimi is connected, the question, context, profiles, and conversation are sent through the server to Kimi to generate responses. Credentials stay on the server. The app does not store a conversation database; responses may be held briefly in server memory for retries. Kimi’s own data policy applies.",
                "عند توصيل Kimi، يُرسل السؤال والسياق والشخصيات والحوار عبر الخادم إلى Kimi لتوليد الردود. تبقى المفاتيح على الخادم. لا يحتفظ التطبيق بقاعدة محادثات؛ قد تبقى الردود مؤقتاً في ذاكرة الخادم لإعادة المحاولة. تنطبق سياسة بيانات Kimi.",
              )}
            </p>
            {mode !== "live" && (
              <p className="demo-callout">
                {t(
                  "Demo mode is active until the owner connects Kimi securely. Responses use scripted examples; they are not live AI reasoning.",
                  "يعمل الوضع التوضيحي حتى يربط المالك Kimi بأمان. تستخدم الردود أمثلة مكتوبة وليست تفكيراً مباشراً بالذكاء الاصطناعي.",
                )}
              </p>
            )}
            <h3>
              {t(
                "Perspectives, not impersonations",
                "منظورات لا انتحال للشخصيات",
              )}
            </h3>
            <p>
              {t(
                "Public thinkers are AI simulations inspired by public ideas. Professional and stakeholder roles are generic viewpoints, never the voice of an entire group. Custom profiles are fictional. No real person participated or endorsed generated dialogue.",
                "المفكرون العامون محاكاة مستوحاة من أفكار عامة. الأدوار المهنية وأصحاب المصلحة منظورات عامة وليست صوت مجموعة كاملة. الشخصيات المخصصة خيالية. لم يشارك شخص حقيقي ولم يؤيد الحوار المولد.",
              )}
            </p>
            <p>
              {t(
                "Religious contributions are imagined interpretations, never revelation or authoritative guidance. Tradition-based mode avoids direct dramatization. No source retrieval is connected: significant factual claims should be independently verified.",
                "المساهمات الدينية تفسيرات متخيلة وليست وحياً أو إرشاداً دينياً ملزماً. يتجنب النمط التراثي التمثيل المباشر. لا يتصل التطبيق باسترجاع المصادر؛ يجب التحقق مستقلاً من الادعاءات الواقعية المهمة.",
              )}
            </p>
          </div>
        </DialogContent>
      </Dialog>
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent dir={ar ? "rtl" : "ltr"}>
          <AlertDialogTitle>
            {t("Delete this conversation?", "حذف هذه المحادثة؟")}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {t(
              "This removes the saved session from your account and starts a new table. Download anything you want to keep first.",
              "سيحذف هذا الجلسة المحفوظة من حسابك ويبدأ طاولة جديدة. نزّل أولاً ما تود الاحتفاظ به.",
            )}
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>
              {t("Keep conversation", "احتفظ بالمحادثة")}
            </AlertDialogCancel>
            <AlertDialogAction onClick={deleteSession}>
              {t("Delete session", "حذف الجلسة")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}
