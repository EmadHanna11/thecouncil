import {
  accountForRequest,
  consumeUsage,
  usageForAccount,
} from "@/lib/server-account";

export const dynamic = "force-dynamic";
const headers = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json",
};
const json = (value: unknown, status = 200) =>
  new Response(JSON.stringify(value), { status, headers });

export async function GET(request: Request) {
  const account = await accountForRequest(request);
  return account
    ? json({ usage: await usageForAccount(account) })
    : json({ error: "UNAUTHORIZED" }, 401);
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin)
    return json({ error: "ORIGIN" }, 403);
  const result = await consumeUsage(request);
  if (!result) return json({ error: "UNAUTHORIZED" }, 401);
  return result.consumed
    ? json({ usage: result.usage })
    : json({ error: "NO_DISCUSSIONS", usage: result.usage }, 429);
}
