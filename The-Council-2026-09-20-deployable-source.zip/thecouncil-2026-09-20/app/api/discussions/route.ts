import { validateSession } from "@/lib/roundtable";
import { accountForRequest, database } from "@/lib/server-account";

export const dynamic = "force-dynamic";
const headers = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json",
};
const json = (value: unknown, status = 200) =>
  new Response(JSON.stringify(value), { status, headers });

export async function GET(request: Request) {
  const account = await accountForRequest(request);
  if (!account) return json({ error: "UNAUTHORIZED" }, 401);
  const rows = await database()
    .prepare(
      "SELECT id, title, updated_at, session_json FROM discussions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100",
    )
    .bind(account.id)
    .all<{
      id: string;
      title: string;
      updated_at: number;
      session_json: string;
    }>();
  const items = (rows.results || []).flatMap((row) => {
    try {
      const session = JSON.parse(row.session_json);
      return validateSession(session)
        ? [
            {
              id: row.id,
              owner: account.email,
              title: row.title,
              updatedAt: row.updated_at,
              session,
            },
          ]
        : [];
    } catch {
      return [];
    }
  });
  return json({ items });
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin)
    return json({ error: "ORIGIN" }, 403);
  const account = await accountForRequest(request);
  if (!account) return json({ error: "UNAUTHORIZED" }, 401);
  try {
    const raw = await request.text();
    if (raw.length > 320000) return json({ error: "TOO_LARGE" }, 413);
    const body = JSON.parse(raw) as {
      id?: unknown;
      title?: unknown;
      updatedAt?: unknown;
      session?: unknown;
    };
    if (
      typeof body.id !== "string" ||
      body.id.length > 100 ||
      (body.title !== undefined &&
        (typeof body.title !== "string" || body.title.length > 100)) ||
      typeof body.updatedAt !== "number" ||
      !validateSession(body.session)
    )
      return json({ error: "INVALID" }, 400);
    await database()
      .prepare(
        "INSERT INTO discussions (id, user_id, title, updated_at, session_json) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id, user_id) DO UPDATE SET title = excluded.title, updated_at = excluded.updated_at, session_json = excluded.session_json",
      )
      .bind(
        body.id,
        account.id,
        body.title || "",
        body.updatedAt,
        JSON.stringify(body.session),
      )
      .run();
    return json({ ok: true });
  } catch (error) {
    return json(
      { error: error instanceof SyntaxError ? "FORMAT" : "SAVE_FAILED" },
      500,
    );
  }
}

export async function DELETE(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin)
    return json({ error: "ORIGIN" }, 403);
  const account = await accountForRequest(request);
  if (!account) return json({ error: "UNAUTHORIZED" }, 401);
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!id || id.length > 100) return json({ error: "INVALID" }, 400);
  await database()
    .prepare("DELETE FROM discussions WHERE id = ? AND user_id = ?")
    .bind(id, account.id)
    .run();
  return json({ ok: true });
}
