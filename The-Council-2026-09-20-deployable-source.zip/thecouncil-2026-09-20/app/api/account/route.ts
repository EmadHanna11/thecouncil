import {
  accountForRequest,
  clearSession,
  createSession,
  database,
  decodeSalt,
  encodeSalt,
  passwordHash,
  usageForAccount,
} from "@/lib/server-account";

export const dynamic = "force-dynamic";
const responseHeaders = {
  "Cache-Control": "no-store",
  "Content-Type": "application/json",
};
const json = (value: unknown, status = 200, headers: HeadersInit = {}) =>
  new Response(JSON.stringify(value), {
    status,
    headers: { ...responseHeaders, ...headers },
  });
const cleanEmail = (value: unknown) =>
  typeof value === "string" ? value.trim().toLowerCase() : "";
const accountJson = async (
  account: NonNullable<Awaited<ReturnType<typeof accountForRequest>>>,
) => ({
  id: account.id,
  email: account.email,
  displayName: account.display_name,
  avatarData: account.avatar_data,
  plan: account.plan === "premium" ? "premium" : account.plan === "paid" ? "paid" : "free",
  preferredLang: account.preferred_lang === "ar" ? "ar" : "en",
  usage: await usageForAccount(account),
});

export async function GET(request: Request) {
  const account = await accountForRequest(request);
  return account
    ? json({ account: await accountJson(account) })
    : json({ account: null }, 401);
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin)
    return json({ error: "ORIGIN" }, 403);
  try {
    const raw = await request.text();
    if (raw.length > 400000) return json({ error: "TOO_LARGE" }, 413);
    const body = JSON.parse(raw) as Record<string, unknown>;
    const action = body.action;
    if (action === "signout") {
      return json({ ok: true }, 200, {
        "Set-Cookie": await clearSession(request),
      });
    }
    if (action === "profile") {
      const account = await accountForRequest(request);
      if (!account) return json({ error: "UNAUTHORIZED" }, 401);
      const displayName =
        typeof body.displayName === "string"
          ? body.displayName.trim().slice(0, 80)
          : "";
      const avatarData =
        typeof body.avatarData === "string" ? body.avatarData : "";
      const preferredLang = body.preferredLang === "ar" ? "ar" : "en";
      if (
        avatarData &&
        (!avatarData.startsWith("data:image/") || avatarData.length > 350000)
      )
        return json({ error: "AVATAR" }, 400);
      await database()
        .prepare(
          "UPDATE users SET display_name = ?, avatar_data = ?, preferred_lang = ?, updated_at = ? WHERE id = ?",
        )
        .bind(displayName, avatarData, preferredLang, Date.now(), account.id)
        .run();
      const updated = await accountForRequest(request);
      return json({ account: await accountJson(updated!) });
    }

    const email = cleanEmail(body.email);
    const password = typeof body.password === "string" ? body.password : "";
    if (!/^\S+@\S+\.\S+$/.test(email)) return json({ error: "EMAIL" }, 400);
    if (password.length < 8 || password.length > 200)
      return json({ error: "PASSWORD" }, 400);
    if (action === "create") {
      const existing = await database()
        .prepare("SELECT id FROM users WHERE email = ?")
        .bind(email)
        .first();
      if (existing) return json({ error: "EXISTS" }, 409);
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const now = Date.now();
      const id = crypto.randomUUID();
      const displayName = email
        .split("@")[0]
        .replace(/[._-]+/g, " ")
        .replace(/\b\w/g, (letter) => letter.toUpperCase())
        .slice(0, 80);
      await database()
        .prepare(
          "INSERT INTO users (id, email, password_hash, password_salt, display_name, avatar_data, plan, preferred_lang, created_at, updated_at) VALUES (?, ?, ?, ?, ?, '', ?, ?, ?, ?)",
        )
        .bind(
          id,
          email,
          await passwordHash(password, salt),
          encodeSalt(salt),
          displayName,
          email === "eng.emadhanna84@gmail.com" ? "premium" : "free",
          body.lang === "ar" ? "ar" : "en",
          now,
          now,
        )
        .run();
      const cookie = await createSession(id);
      const account = await database()
        .prepare(
          "SELECT id, email, display_name, avatar_data, plan, preferred_lang FROM users WHERE id = ?",
        )
        .bind(id)
        .first<any>();
      return json({ account: await accountJson(account) }, 201, {
        "Set-Cookie": cookie,
      });
    }
    if (action === "signin") {
      const account = await database()
        .prepare(
          "SELECT id, email, password_hash, password_salt, display_name, avatar_data, plan, preferred_lang FROM users WHERE email = ?",
        )
        .bind(email)
        .first<any>();
      if (
        !account ||
        (await passwordHash(password, decodeSalt(account.password_salt))) !==
          account.password_hash
      )
        return json({ error: "INVALID" }, 401);
      const cookie = await createSession(account.id);
      return json({ account: await accountJson(account) }, 200, {
        "Set-Cookie": cookie,
      });
    }
    return json({ error: "INVALID_ACTION" }, 400);
  } catch (error) {
    console.error(
      "ACCOUNT_API_ERROR",
      error instanceof Error ? error.stack || error.message : String(error),
    );
    return json(
      { error: error instanceof SyntaxError ? "FORMAT" : "ACCOUNT_ERROR" },
      500,
    );
  }
}
