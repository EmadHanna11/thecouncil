import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={
  title:'The Council | المجلس',
  description:'Bring two to five contrasting AI-simulated perspectives into one thoughtful council. You host the conversation.',
  applicationName:'The Council',
  icons:{icon:'/council-logo.png',shortcut:'/council-logo.png',apple:'/council-logo.png'},
};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
