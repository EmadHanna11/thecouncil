import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { dirname, join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';

const projectRoot = process.cwd();
const ssrDir = join(projectRoot, 'dist', 'server', 'ssr');
const vendorDir = join(ssrDir, 'vendor');
const require = createRequire(import.meta.url);

const serverEntry = join(projectRoot, 'dist', 'server', 'index.js');
const builtServer = await import(`${pathToFileURL(serverEntry)}?snapshot=${Date.now()}`);
const homeResponse = await builtServer.default(new Request('http://localhost/'));
if (!homeResponse.ok) {
  throw new Error(`Could not snapshot the homepage: HTTP ${homeResponse.status}`);
}
const homeHtml = await homeResponse.text();
await writeFile(
  join(projectRoot, 'dist', 'server', 'home-html.js'),
  `export default ${JSON.stringify(homeHtml)};\n`,
);

await rm(vendorDir, { recursive: true, force: true });
await mkdir(vendorDir, { recursive: true });

const commonJsModules = {
  'react.cjs': join(projectRoot, 'node_modules', 'react', 'cjs', 'react.production.js'),
  'react-jsx-runtime.cjs': join(projectRoot, 'node_modules', 'react', 'cjs', 'react-jsx-runtime.production.js'),
  'react-dom.cjs': join(projectRoot, 'node_modules', 'react-dom', 'cjs', 'react-dom.production.js'),
  'react-dom-server-edge-runtime.cjs': join(projectRoot, 'node_modules', 'react-dom', 'cjs', 'react-dom-server.edge.production.js'),
  'react-dom-server-legacy-browser.cjs': join(projectRoot, 'node_modules', 'react-dom', 'cjs', 'react-dom-server-legacy.browser.production.js'),
  'scheduler.cjs': join(projectRoot, 'node_modules', '.pnpm', 'scheduler@0.27.0', 'node_modules', 'scheduler', 'cjs', 'scheduler.production.js'),
};

for (const [name, sourcePath] of Object.entries(commonJsModules)) {
  let source = await readFile(sourcePath, 'utf8');
  source = source
    .replaceAll('require("react")', 'require("./react.cjs")')
    .replaceAll('require("react-dom")', 'require("./react-dom.cjs")')
    .replaceAll('require("scheduler")', 'require("./scheduler.cjs")');
  await writeFile(join(vendorDir, name), source);
}

await writeFile(
  join(vendorDir, 'react-dom-server-edge.cjs'),
  `'use strict';\nconst modern = require('./react-dom-server-edge-runtime.cjs');\nconst legacy = require('./react-dom-server-legacy-browser.cjs');\nexports.version = modern.version;\nexports.renderToReadableStream = modern.renderToReadableStream;\nexports.renderToString = legacy.renderToString;\nexports.renderToStaticMarkup = legacy.renderToStaticMarkup;\nexports.resume = modern.resume;\n`,
);
await writeFile(
  join(vendorDir, 'react-dom-static-edge.cjs'),
  `'use strict';\nconst server = require('./react-dom-server-edge-runtime.cjs');\nexports.version = server.version;\nexports.prerender = server.prerender;\nexports.resumeAndPrerender = server.resumeAndPrerender;\n`,
);

const packages = {
  react: ['react', 'react.cjs'],
  'react-jsx-runtime': ['react/jsx-runtime', 'react-jsx-runtime.cjs'],
  'react-dom': ['react-dom', 'react-dom.cjs'],
  'react-dom-server-edge': ['react-dom/server.edge', 'react-dom-server-edge.cjs'],
  'react-dom-static-edge': ['react-dom/static.edge', 'react-dom-static-edge.cjs'],
};
for (const [name, [packageName, commonJsFile]] of Object.entries(packages)) {
  const names = Object.keys(require(packageName)).filter(
    (key) => key !== 'default' && /^[A-Za-z_$][\w$]*$/.test(key),
  );
  const defaultExport = packageName === 'react' ? 'export default moduleValue;\n' : '';
  await writeFile(
    join(vendorDir, `${name}.js`),
    `import * as moduleNamespace from './${commonJsFile}';\nconst moduleValue = moduleNamespace.default ?? moduleNamespace;\n${defaultExport}export const { ${names.join(', ')} } = moduleValue;\n`,
  );
}

const staticDir = join(ssrDir, '_next', 'static');
const pageChunks = (await readdir(staticDir))
  .filter((name) => /^page-.+\.js$/.test(name))
  .map((name) => join('_next', 'static', name));
const files = [
  'index.js',
  join('_next', 'static', 'layout-segment-context-6sYF5ZVQ.js'),
  join('_next', 'static', 'streamed-icons-JsA12Qah.js'),
  join('_next', 'static', 'error-boundary-CfJR1rkC.js'),
  join('_next', 'static', 'app-router-scroll-B-C19qlb.js'),
  ...pageChunks,
];
const replacements = {
  react: 'react.js',
  'react/jsx-runtime': 'react-jsx-runtime.js',
  'react-dom': 'react-dom.js',
  'react-dom/server.edge': 'react-dom-server-edge.js',
  'react-dom/static.edge': 'react-dom-static-edge.js',
};

for (const relativePath of files) {
  const file = join(ssrDir, relativePath);
  let source = await readFile(file, 'utf8');
  for (const [specifier, vendorFile] of Object.entries(replacements)) {
    let replacement = relative(dirname(file), join(vendorDir, vendorFile)).replaceAll('\\', '/');
    if (!replacement.startsWith('.')) replacement = `./${replacement}`;
    source = source
      .replaceAll(`from"${specifier}"`, `from"${replacement}"`)
      .replaceAll(`from'${specifier}'`, `from'${replacement}'`)
      .replaceAll(`import"${specifier}"`, `import"${replacement}"`)
      .replaceAll(`import'${specifier}'`, `import'${replacement}'`)
      .replaceAll(`import(\"${specifier}\")`, `import(\"${replacement}\")`)
      .replaceAll(`import('${specifier}')`, `import('${replacement}')`);
  }
  await writeFile(file, source);
}
