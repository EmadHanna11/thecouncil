import { readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const serverDir = join(process.cwd(), 'dist', 'server');
const entry = join(serverDir, 'index.js');
const handlerEntry = join(serverDir, 'vinext-handler.js');
const marker = 'roundtable-sites-worker';
const built = await readFile(entry, 'utf8');

if (!built.includes(marker)) {
  await rename(entry, handlerEntry);
  await writeFile(
    entry,
    `export * from './vinext-handler.js';\nimport handler from './vinext-handler.js';\nimport homeHtml from './home-html.js';\n// ${marker}\nexport default {\n  fetch(request, env, ctx) {\n    const url = new URL(request.url);\n    const acceptsHtml = request.headers.get('accept')?.includes('text/html');\n    if (request.method === 'GET' && url.pathname === '/favicon.ico') {\n      return new Response(null, { status: 204 });\n    }\n    if (request.method === 'GET' && url.pathname === '/' && acceptsHtml) {\n      return new Response(homeHtml, { headers: { 'content-type': 'text/html; charset=utf-8' } });\n    }\n    return handler(request, env, ctx);\n  },\n};\n`,
  );
}
