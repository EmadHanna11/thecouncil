"use client";

import { useMemo, useState } from "react";
import {
  Clock3,
  Download,
  MessageCircle,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Trash2,
  Users,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { nameOf, type Lang, type Session } from "@/lib/roundtable";

export type DiscussionRecord = {
  id: string;
  owner: string;
  title?: string;
  updatedAt: number;
  session: Session;
};

type Props = {
  lang: Lang;
  items: DiscussionRecord[];
  onStart: () => void;
  onOpen: (item: DiscussionRecord) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
};

export default function DiscussionDashboard({
  lang,
  items,
  onStart,
  onOpen,
  onDelete,
  onRename,
}: Props) {
  const ar = lang === "ar";
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  const [query, setQuery] = useState("");
  const [pendingDelete, setPendingDelete] = useState<DiscussionRecord | null>(
    null,
  );
  const [renaming, setRenaming] = useState<DiscussionRecord | null>(null);
  const [title, setTitle] = useState("");
  const visible = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    if (!needle) return items;
    return items.filter((item) => {
      const people = item.session.participants
        .map((p) => nameOf(p, lang))
        .join(" ");
      return `${item.title || ""} ${item.session.question} ${people}`
        .toLocaleLowerCase()
        .includes(needle);
    });
  }, [items, lang, query]);
  const formatDate = (value: number) =>
    new Intl.DateTimeFormat(ar ? "ar-JO" : "en-GB", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(value);

  return (
    <section className="discussion-dashboard" aria-labelledby="dashboard-title">
      <div className="dashboard-hero">
        <div>
          <span className="eyebrow">{t("YOUR COUNCIL", "مجلسك")}</span>
          <h1 id="dashboard-title">
            {t(
              "Where thoughtful conversations continue.",
              "حيث تستمر الحوارات المتأنية.",
            )}
          </h1>
          <p>
            {t(
              "Start with a new question, or return to a discussion exactly where you left it.",
              "ابدأ بسؤال جديد، أو عُد إلى نقاشك من حيث توقفت تماماً.",
            )}
          </p>
        </div>
        <button className="primary dashboard-start" onClick={onStart}>
          <Plus size={19} />
          {t("Start new discussion", "ابدأ نقاشاً جديداً")}
        </button>
      </div>

      <div className="dashboard-section-head">
        <div>
          <h2>{t("Previous discussions", "نقاشاتك السابقة")}</h2>
          <span>
            {t(
              `${items.length} saved to your account`,
              `${items.length} محفوظة في حسابك`,
            )}
          </span>
        </div>
        {items.length > 3 && (
          <label className="discussion-search">
            <Search size={17} />
            <span className="sr-only">
              {t("Search discussions", "ابحث في النقاشات")}
            </span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t("Search discussions", "ابحث في النقاشات")}
            />
          </label>
        )}
      </div>

      {visible.length ? (
        <div className="discussion-list">
          {visible.map((item) => {
            const session = item.session;
            const participants = session.participants;
            const status =
              session.stage === "discuss"
                ? t("In discussion", "نقاش جارٍ")
                : session.stage === "assemble"
                  ? t("Table ready", "الطاولة جاهزة")
                  : t("Draft", "مسودة");
            return (
              <article className="discussion-row" key={item.id}>
                <button
                  className="discussion-row-main"
                  onClick={() => onOpen(item)}
                >
                  <div className="discussion-row-copy">
                    <span className="discussion-status">{status}</span>
                    <h3>
                      {item.title ||
                        session.question ||
                        t("Untitled discussion", "نقاش بلا عنوان")}
                    </h3>
                    {item.title && <p>{session.question}</p>}
                    <div className="discussion-row-meta">
                      <span>
                        <Clock3 size={14} />
                        {formatDate(item.updatedAt)}
                      </span>
                      {participants.length > 0 && (
                        <span>
                          <Users size={14} />
                          {participants
                            .slice(0, 2)
                            .map((p) => nameOf(p, lang))
                            .join(" · ")}
                          {participants.length > 2
                            ? ` +${participants.length - 2}`
                            : ""}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
                <DropdownMenu>
                  <DropdownMenuTrigger
                    className="discussion-more"
                    aria-label={t("Discussion options", "خيارات النقاش")}
                  >
                    <MoreHorizontal size={18} />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" dir={ar ? "rtl" : "ltr"}>
                    <DropdownMenuItem
                      onClick={() => {
                        setRenaming(item);
                        setTitle(item.title || "");
                      }}
                    >
                      <Pencil />
                      {t("Rename", "إعادة التسمية")}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => {
                        const blob = new Blob(
                          [JSON.stringify(item.session, null, 2)],
                          { type: "application/json" },
                        );
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement("a");
                        link.href = url;
                        link.download = `council-${item.id}.json`;
                        link.click();
                        URL.revokeObjectURL(url);
                      }}
                    >
                      <Download />
                      {t("Export", "تصدير")}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      variant="destructive"
                      onClick={() => setPendingDelete(item)}
                    >
                      <Trash2 />
                      {t("Delete", "حذف")}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="dashboard-empty">
          <MessageCircle size={25} />
          <h3>
            {query
              ? t("No matching discussions", "لا توجد نقاشات مطابقة")
              : t("Your next question starts here", "سؤالك القادم يبدأ هنا")}
          </h3>
          <p>
            {query
              ? t(
                  "Try a different word or participant name.",
                  "جرّب كلمة مختلفة أو اسم مشارك آخر.",
                )
              : t(
                  "New discussions will be saved to your account automatically.",
                  "ستُحفظ نقاشاتك الجديدة تلقائياً في حسابك.",
                )}
          </p>
          {!query && (
            <button className="outline" onClick={onStart}>
              <Plus size={17} />
              {t("Start new discussion", "ابدأ نقاشاً جديداً")}
            </button>
          )}
        </div>
      )}

      <AlertDialog
        open={Boolean(pendingDelete)}
        onOpenChange={(open) => {
          if (!open) setPendingDelete(null);
        }}
      >
        <AlertDialogContent dir={ar ? "rtl" : "ltr"}>
          <AlertDialogTitle>
            {t("Delete this discussion?", "حذف هذا النقاش؟")}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {t(
              "This removes the discussion from your account on every device. This action cannot be undone.",
              "سيُحذف هذا النقاش من حسابك على جميع الأجهزة، ولا يمكن التراجع عن ذلك.",
            )}
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>
              {t("Keep discussion", "احتفظ بالنقاش")}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (pendingDelete) onDelete(pendingDelete.id);
                setPendingDelete(null);
              }}
            >
              {t("Delete discussion", "حذف النقاش")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog
        open={Boolean(renaming)}
        onOpenChange={(open) => {
          if (!open) setRenaming(null);
        }}
      >
        <DialogContent dir={ar ? "rtl" : "ltr"}>
          <DialogTitle>
            {t("Rename discussion", "إعادة تسمية النقاش")}
          </DialogTitle>
          <DialogDescription>
            {t(
              "Add a short title without changing the original question.",
              "أضف عنواناً قصيراً دون تغيير السؤال الأصلي.",
            )}
          </DialogDescription>
          <label className="field-label">
            {t("Title", "العنوان")}
            <input
              autoFocus
              maxLength={100}
              value={title}
              onChange={(event) => setTitle(event.target.value)}
            />
          </label>
          <div className="inline-actions">
            <button className="quiet" onClick={() => setRenaming(null)}>
              {t("Cancel", "إلغاء")}
            </button>
            <button
              className="primary"
              onClick={() => {
                if (renaming) onRename(renaming.id, title.trim());
                setRenaming(null);
              }}
            >
              {t("Save", "حفظ")}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}
