"use client";

import { useRef, useState } from "react";
import {
  Camera,
  ChevronDown,
  CreditCard,
  LogOut,
  Settings,
  UserRound,
} from "lucide-react";
import type { Lang } from "@/lib/roundtable";
import type { BrowserAccount } from "./account-gate";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function AccountMenu({
  account,
  lang,
  onAccountChange,
  onLanguageChange,
  onSignOut,
}: {
  account: BrowserAccount;
  lang: Lang;
  onAccountChange: (account: BrowserAccount) => void;
  onLanguageChange: (lang: Lang) => void;
  onSignOut: () => void;
}) {
  const ar = lang === "ar";
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(account.displayName);
  const [avatar, setAvatar] = useState(account.avatarData);
  const [preferredLang, setPreferredLang] = useState<Lang>(
    account.preferredLang,
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const initials = (account.displayName || account.email)
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  const unlimited = account.plan === "premium";
  const percent = unlimited ? 100 : Math.round(
    (account.usage.remaining / Math.max(1, account.usage.limit)) * 100,
  );
  const reset = account.usage.resetAt
    ? new Intl.DateTimeFormat(ar ? "ar-JO" : "en", {
        hour: "numeric",
        minute: "2-digit",
      }).format(account.usage.resetAt)
    : null;
  const choosePhoto = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 250_000) {
      setError(
        t(
          "Choose an image smaller than 250 KB.",
          "اختر صورة أصغر من 250 كيلوبايت.",
        ),
      );
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setAvatar(String(reader.result || ""));
    reader.readAsDataURL(file);
  };
  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "profile",
          displayName: name,
          avatarData: avatar,
          preferredLang,
        }),
      });
      const data = (await response.json()) as {
        account?: BrowserAccount;
        error?: string;
      };
      if (!response.ok || !data.account)
        throw new Error(data.error || "SAVE_FAILED");
      onAccountChange(data.account);
      onLanguageChange(preferredLang);
      setOpen(false);
    } catch {
      setError(
        t(
          "Could not save your profile. Please try again.",
          "تعذر حفظ ملفك الشخصي. حاول مرة أخرى.",
        ),
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          className="profile-trigger"
          aria-label={t("Open profile menu", "فتح قائمة الملف الشخصي")}
        >
          <Avatar>
            <AvatarImage src={account.avatarData || undefined} />
            <AvatarFallback>
              {initials || <UserRound size={16} />}
            </AvatarFallback>
          </Avatar>
          <ChevronDown size={14} />
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="profile-menu"
          align="end"
          dir={ar ? "rtl" : "ltr"}
        >
          <DropdownMenuLabel className="profile-menu-identity">
            <strong>{account.displayName || t("Your account", "حسابك")}</strong>
            <span>{account.email}</span>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <div className="profile-usage">
            <div>
              <span>
                {unlimited
                  ? t("Premium owner", "المالك المميز")
                  : account.plan === "paid"
                  ? t("Paid plan", "الخطة المدفوعة")
                  : t("Free plan", "الخطة المجانية")}
              </span>
              <b>
                {unlimited ? t("Unlimited", "غير محدود") : `${account.usage.remaining}/${account.usage.limit} ${t("left", "متبقي")}`}
              </b>
            </div>
            <div className="usage-track">
              <span style={{ width: `${percent}%` }} />
            </div>
            {reset && (
              <small>
                {t(`Next credit at ${reset}`, `الرصيد التالي الساعة ${reset}`)}
              </small>
            )}
          </div>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setOpen(true)}>
            <Settings />
            {t("Profile & settings", "الملف والإعدادات")}
          </DropdownMenuItem>
          <DropdownMenuItem disabled>
            <CreditCard />
            {t("Plans — coming soon", "الخطط — قريباً")}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem variant="destructive" onClick={onSignOut}>
            <LogOut />
            {t("Sign out", "تسجيل الخروج")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="profile-dialog" dir={ar ? "rtl" : "ltr"}>
          <DialogTitle>
            {t("Profile & settings", "الملف الشخصي والإعدادات")}
          </DialogTitle>
          <DialogDescription>
            {t(
              "Personalize how your account appears at the table.",
              "خصّص طريقة ظهور حسابك على الطاولة.",
            )}
          </DialogDescription>
          <div className="profile-photo-row">
            <Avatar size="lg">
              <AvatarImage src={avatar || undefined} />
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <button
              className="outline"
              onClick={() => fileRef.current?.click()}
            >
              <Camera size={16} />
              {t("Choose photo", "اختر صورة")}
            </button>
            {avatar && (
              <button className="quiet" onClick={() => setAvatar("")}>
                {t("Remove", "إزالة")}
              </button>
            )}
            <input
              ref={fileRef}
              hidden
              type="file"
              accept="image/*"
              onChange={(event) => choosePhoto(event.target.files?.[0])}
            />
          </div>
          <label className="field-label">
            {t("Display name", "اسم العرض")}
            <input
              value={name}
              maxLength={80}
              onChange={(event) => setName(event.target.value)}
            />
          </label>
          <label className="field-label">
            {t("Email", "البريد الإلكتروني")}
            <input value={account.email} disabled />
          </label>
          <label className="field-label">
            {t("Language", "اللغة")}
            <select
              value={preferredLang}
              onChange={(event) => setPreferredLang(event.target.value as Lang)}
            >
              <option value="en">English</option>
              <option value="ar">العربية</option>
            </select>
          </label>
          <div className="profile-plan-card">
            <span>
              {unlimited
                ? t("Premium owner", "المالك المميز")
                : account.plan === "paid"
                ? t("Paid plan", "الخطة المدفوعة")
                : t("Free plan", "الخطة المجانية")}
            </span>
            <strong>
              {unlimited ? t("Unlimited discussions", "نقاشات غير محدودة") : `${account.usage.remaining} ${t("discussions available", "نقاشات متاحة")}`}
            </strong>
            <small>
              {unlimited ? t("Your owner account never has a discussion limit.", "حساب المالك الخاص بك بلا حد للنقاشات.") : t("Usage refreshes on a rolling 24-hour window.", "يتجدد الاستخدام ضمن نافذة متحركة مدتها 24 ساعة.")}
            </small>
          </div>
          {error && <p className="auth-error">{error}</p>}
          <div className="inline-actions">
            <button className="quiet" onClick={() => setOpen(false)}>
              {t("Cancel", "إلغاء")}
            </button>
            <button
              className="primary"
              disabled={busy || !name.trim()}
              onClick={save}
            >
              {busy
                ? t("Saving…", "جارٍ الحفظ…")
                : t("Save changes", "حفظ التغييرات")}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
