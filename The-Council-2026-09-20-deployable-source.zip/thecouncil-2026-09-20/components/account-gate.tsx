"use client";

import { useState } from "react";
import {
  ArrowRight,
  Clock3,
  Eye,
  EyeOff,
  Globe2,
  LockKeyhole,
  Mail,
} from "lucide-react";
import type { Lang } from "@/lib/roundtable";
import CouncilMark from "./council-mark";

const LEGACY_ACCOUNTS_KEY = "roundtable.accounts.v1";
export type UsageSummary = {
  limit: number;
  used: number;
  remaining: number;
  resetAt: number | null;
};
export type BrowserAccount = {
  id: string;
  email: string;
  displayName: string;
  avatarData: string;
  plan: "free" | "paid" | "premium";
  preferredLang: Lang;
  usage: UsageSummary;
};

async function accountRequest(body?: unknown) {
  const response = await fetch("/api/account", {
    method: body ? "POST" : "GET",
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await response.json().catch(() => ({}))) as {
    account?: BrowserAccount;
    error?: string;
  };
  if (!response.ok || !data.account) throw new Error(data.error || "INVALID");
  return data.account;
}
export async function currentBrowserAccount() {
  try {
    return await accountRequest();
  } catch {
    return null;
  }
}
export async function signOutBrowserAccount() {
  await fetch("/api/account", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "signout" }),
  });
}
export async function consumeDiscussion() {
  const response = await fetch("/api/usage", { method: "POST" });
  const data = (await response.json().catch(() => ({}))) as UsageSummary & {
    error?: string;
  };
  if (!response.ok) throw new Error(data.error || "NO_DISCUSSIONS");
  return data;
}
function hasLegacyAccount(email: string) {
  try {
    const accounts = JSON.parse(
      localStorage.getItem(LEGACY_ACCOUNTS_KEY) || "{}",
    ) as Record<string, unknown>;
    return Boolean(accounts[email.trim().toLowerCase()]);
  } catch {
    return false;
  }
}

export default function AccountGate({
  lang,
  onLanguageChange,
  onSignedIn,
}: {
  lang: Lang;
  onLanguageChange: (lang: Lang) => void;
  onSignedIn: (account: BrowserAccount) => void;
}) {
  const ar = lang === "ar";
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  const [view, setView] = useState<"signin" | "create">("create");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      onSignedIn(await accountRequest({ action: view, email, password, lang }));
    } catch (reason) {
      const code = (reason as Error).message;
      const legacyHint =
        view === "signin" && code === "INVALID" && hasLegacyAccount(email);
      setError(
        legacyHint
          ? t(
              "Your earlier account was saved only on this device. Choose Create account once to sync it securely.",
              "كان حسابك السابق محفوظاً على هذا الجهاز فقط. اختر إنشاء حساب مرة واحدة لمزامنته بأمان.",
            )
          : code === "EMAIL"
            ? t(
                "Enter a valid email address.",
                "أدخل بريداً إلكترونياً صحيحاً.",
              )
            : code === "PASSWORD"
              ? t("Use at least 8 characters.", "استخدم 8 أحرف على الأقل.")
              : code === "EXISTS"
                ? t(
                    "An account with this email already exists. Sign in instead.",
                    "يوجد حساب بهذا البريد. سجّل الدخول بدلاً من ذلك.",
                  )
                : code === "ACCOUNT_ERROR"
                  ? t(
                      "Account service is temporarily unavailable. Please try again.",
                      "خدمة الحساب غير متاحة مؤقتاً. يرجى المحاولة مرة أخرى.",
                    )
                : t(
                    "Email or password is incorrect.",
                    "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
                  ),
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <main className="auth-page" dir={ar ? "rtl" : "ltr"}>
      <header className="auth-header">
        <div className="auth-product-brand">
          <CouncilMark className="auth-product-logo" state="rest" />
          <span>{t("The Council", "المجلس")}</span>
        </div>
        <div className="auth-header-tools">
          <div className="auth-owner">
            <span>{t("An Emad Hanna product", "منتج من شركة عماد حنا")}</span>
            <img
              src="/emad-hanna-company-logo.png"
              alt={t("Emad Hanna company", "شركة عماد حنا")}
            />
          </div>
          <button
            className="quiet"
            onClick={() => onLanguageChange(ar ? "en" : "ar")}
          >
            <Globe2 size={17} />
            {ar ? "English" : "العربية"}
          </button>
        </div>
      </header>
      <section className="auth-shell">
        <div className="auth-story">
          <CouncilMark
            className="auth-story-logo"
            state="seating"
            label={t("The Council", "المجلس")}
          />
          <h1>
            {t(
              "Topics deserve more than one perspective.",
              "مواضيع تستحق أكثر من وجهة نظر",
            )}
          </h1>
        </div>
        <form className="auth-card" onSubmit={submit}>
          <div className="auth-card-heading">
            <h2>
              {view === "create"
                ? t("Create your account", "إنشاء حساب")
                : t("Welcome back", "مرحباً بعودتك")}
            </h2>
            <p>
              {t(
                "Your discussions stay with your account across devices.",
                "تبقى نقاشاتك مرتبطة بحسابك عبر أجهزتك.",
              )}
            </p>
          </div>
          <label>
            <span>{t("Email", "البريد الإلكتروني")}</span>
            <div className="auth-input">
              <Mail size={18} />
              <input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="name@example.com"
              />
            </div>
          </label>
          <label>
            <span>{t("Password", "كلمة المرور")}</span>
            <div className="auth-input">
              <LockKeyhole size={18} />
              <input
                type={show ? "text" : "password"}
                autoComplete={
                  view === "create" ? "new-password" : "current-password"
                }
                minLength={8}
                required
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder={t("At least 8 characters", "8 أحرف على الأقل")}
              />
              <button
                type="button"
                aria-label={t("Show password", "إظهار كلمة المرور")}
                onClick={() => setShow((value) => !value)}
              >
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </label>
          {error && (
            <p className="auth-error" role="alert">
              {error}
            </p>
          )}
          <button className="primary auth-submit" disabled={busy}>
            {busy
              ? t("Please wait…", "يرجى الانتظار…")
              : view === "create"
                ? t("Create account and continue", "إنشاء الحساب والمتابعة")
                : t("Sign in", "تسجيل الدخول")}
            <ArrowRight size={18} />
          </button>
          <button
            className="auth-switch"
            type="button"
            onClick={() => {
              setView((value) => (value === "create" ? "signin" : "create"));
              setError("");
            }}
          >
            {view === "create"
              ? t("Already have an account? Sign in", "لديك حساب؟ سجّل الدخول")
              : t("New here? Create an account", "مستخدم جديد؟ أنشئ حساباً")}
          </button>
          <div className="auth-allowance">
            <Clock3 size={16} />
            <span>
              {t(
                "Free accounts include two discussions every 24 hours.",
                "تتضمن الحسابات المجانية نقاشين كل 24 ساعة.",
              )}
            </span>
          </div>
        </form>
      </section>
    </main>
  );
}
