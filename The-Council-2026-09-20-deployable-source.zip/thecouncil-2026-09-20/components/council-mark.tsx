'use client';

type CouncilMarkProps={className?:string;state?:'rest'|'seating'|'in-session'|'dissent';label?:string};

export default function CouncilMark({className='',state='rest',label='The Council'}:CouncilMarkProps){
  return <svg className={`council-mark ${className}`} data-state={state} viewBox="0 0 100 100" role={label?'img':undefined} aria-label={label||undefined} fill="none" strokeWidth="7" strokeLinecap="round">
    <g className="council-orbit">
      <line x1="50" y1="12" x2="50" y2="34" stroke="#121316"/>
      <line x1="50" y1="12" x2="50" y2="34" stroke="#121316" transform="rotate(72 50 50)"/>
      <line x1="50" y1="12" x2="50" y2="34" stroke="#121316" transform="rotate(144 50 50)"/>
      <line x1="50" y1="12" x2="50" y2="34" stroke="#121316" transform="rotate(216 50 50)"/>
      <line className="council-stroke--dissent" x1="50" y1="12" x2="50" y2="34" stroke="#C9522D" transform="rotate(288 50 50)"/>
    </g>
    <circle cx="50" cy="50" r="4.5" fill="#0E7C5A"/>
  </svg>;
}
