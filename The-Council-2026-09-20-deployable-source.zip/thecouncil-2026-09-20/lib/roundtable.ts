import personaRows from '../public/personas.json';

export type Lang='en'|'ar';
export type CouncilBrief={position:string;tension:string;reconsider:string};
export type Profile={id:string;name:string;ar:string;role:string;roleAr:string;group:string;expertise:string;expertiseAr:string;priorities:string;prioritiesAr:string;tags:string[];kind:'public'|'generic'|'custom';library?:Record<string,string>;reason?:string;councilBrief?:CouncilBrief;background?:string;perspective?:string};
const domainCategory:Record<string,string>={Business:'business','Economics & Finance':'business','Leadership & Management':'business','Politics & Governance':'ethics','Law & Justice':'ethics',Philosophy:'philosophy','Theology & Religion':'religion','Science & Technology':'technology','Medicine & Health':'personal','Psychology & Human Behavior':'personal','Society & Culture':'ethics',Education:'education','Arts & Literature':'philosophy','Media & Communication':'technology','History & Strategy':'business','Environment & Sustainability':'ethics','Everyday Life & Community Voices':'personal','Provocateurs & Thinking Modes':'philosophy'};
const domainArabic:Record<string,string>={Business:'الأعمال','Economics & Finance':'الاقتصاد والتمويل','Leadership & Management':'القيادة والإدارة','Politics & Governance':'السياسة والحوكمة','Law & Justice':'القانون والعدالة',Philosophy:'الفلسفة','Theology & Religion':'اللاهوت والدين','Science & Technology':'العلوم والتقنية','Medicine & Health':'الطب والصحة','Psychology & Human Behavior':'علم النفس والسلوك','Society & Culture':'المجتمع والثقافة',Education:'التعليم','Arts & Literature':'الفنون والأدب','Media & Communication':'الإعلام والتواصل','History & Strategy':'التاريخ والاستراتيجية','Environment & Sustainability':'البيئة والاستدامة','Everyday Life & Community Voices':'الحياة اليومية وأصوات المجتمع','Provocateurs & Thinking Modes':'محفزات وأنماط التفكير'};
type LibraryRow=Record<string,string>;
export const catalogue:Profile[]=(personaRows as LibraryRow[]).map(r=>({id:r.Persona_ID,name:r.Persona_Name,ar:r.Persona_Name_Arabic,role:r.Tagline,roleAr:domainArabic[r.Domain]||r.Domain,group:r.Basis_Type==='Historical figure'?'historical':'professional',kind:r.Basis_Type==='Archetype'?'generic':'public',expertise:r.Brief_Description,expertiseAr:r.Brief_Description,priorities:r.Key_Values,prioritiesAr:r.Key_Values,tags:[domainCategory[r.Domain]||'personal',r.Domain,r.Sub_Domain].filter(Boolean),library:r}));
export const categories=[['business','Business','الأعمال'],['family','Family','الأسرة'],['religion','Religion','الدين'],['ethics','Ethics','الأخلاق'],['philosophy','Philosophy','الفلسفة'],['education','Education','التعليم'],['technology','Technology','التقنية'],['personal','Personal','قرارات شخصية']];
export const goals=[['explore','Explore a question','استكشاف سؤال'],['decision','Make a decision','اتخاذ قرار'],['problem','Solve a problem','حل مشكلة'],['thesis','Develop a thesis','تطوير أطروحة'],['action','Create an action plan','وضع خطة عمل']];
export const groups=[['all','All perspectives','كل المنظورات'],['historical','Historical thinkers','مفكرون تاريخيون'],['contemporary','Contemporary public figures','شخصيات عامة معاصرة'],['professional','Professional profiles','منظورات مهنية'],['stakeholder','Stakeholder perspectives','أصحاب المصلحة'],['custom','Custom profiles','شخصيات مخصصة']];
export type QuestionIdea=[english:string,arabic:string,category:string];
export const questionBank:Record<string,QuestionIdea[]>={
 business:[
  ['Should our team move to a four-day workweek?','هل ينبغي أن ينتقل فريقنا إلى أسبوع عمل من أربعة أيام؟','business'],
  ['When should a growing company choose resilience over faster growth?','متى ينبغي للشركة النامية أن تختار المرونة بدلاً من النمو الأسرع؟','business'],
  ['How can leaders make difficult cuts without losing trust?','كيف يمكن للقادة اتخاذ قرارات خفض صعبة دون فقدان الثقة؟','business'],
  ['Should employee wellbeing influence how we measure performance?','هل ينبغي أن تؤثر رفاهية الموظفين في طريقة قياس الأداء؟','business'],
  ['What would make this new business idea worth the risk?','ما الذي يجعل فكرة العمل الجديدة جديرة بالمخاطرة؟','business'],
  ['How should a family business balance loyalty and competence?','كيف توازن الشركة العائلية بين الولاء والكفاءة؟','business'],
  ['Which customer problem should we solve first, and why?','أي مشكلة للعميل ينبغي أن نحلها أولاً، ولماذا؟','business'],
 ],
 family:[
  ['How much freedom should teenagers have online?','ما مقدار الحرية التي ينبغي منحها للمراهقين على الإنترنت؟','family'],
  ['How can a family disagree without turning every conflict into a contest?','كيف يمكن للأسرة أن تختلف دون أن يتحول كل خلاف إلى منافسة؟','family'],
  ['When should parents step in, and when should they let children learn?','متى ينبغي للوالدين التدخل، ومتى يتركان الأبناء يتعلمون؟','family'],
  ['How should siblings share responsibility for ageing parents?','كيف ينبغي للإخوة تقاسم مسؤولية رعاية الوالدين المتقدمين في السن؟','family'],
  ['What does a fair division of household work look like?','كيف يبدو التقسيم العادل لأعمال المنزل؟','family'],
  ['How can families protect time together without rejecting technology?','كيف تحمي الأسر وقتها المشترك دون رفض التكنولوجيا؟','family'],
  ['What should guide a difficult decision about where the family will live?','ما الذي ينبغي أن يوجّه قراراً صعباً بشأن مكان سكن الأسرة؟','family'],
 ],
 religion:[
  ['How can faith inform a public decision in a plural society?','كيف يمكن للإيمان أن يسهم في قرار عام داخل مجتمع تعددي؟','religion'],
  ['What is the difference between religious conviction and moral certainty?','ما الفرق بين القناعة الدينية واليقين الأخلاقي؟','religion'],
  ['How should a community respond when tradition and changing circumstances conflict?','كيف يستجيب المجتمع عندما يتعارض التراث مع الظروف المتغيرة؟','religion'],
  ['Can people from different faiths build shared ethical commitments?','هل يستطيع أتباع أديان مختلفة بناء التزامات أخلاقية مشتركة؟','religion'],
  ['What role should doubt play in a mature life of faith?','ما الدور الذي ينبغي أن يؤديه الشك في حياة إيمانية ناضجة؟','religion'],
  ['How can religious leadership hold authority and accountability together?','كيف تجمع القيادة الدينية بين السلطة والمساءلة؟','religion'],
  ['When does preserving unity become avoidance of an important disagreement?','متى يصبح الحفاظ على الوحدة تهرباً من خلاف مهم؟','religion'],
 ],
 ethics:[
  ['Is a good outcome enough to justify a difficult decision?','هل تكفي النتيجة الجيدة لتبرير قرار صعب؟','ethics'],
  ['What do we owe people who carry the risks of our choices?','ماذا ندين للأشخاص الذين يتحملون مخاطر خياراتنا؟','ethics'],
  ['When should fairness mean equal treatment, and when should it mean extra support?','متى تعني العدالة معاملة متساوية، ومتى تعني دعماً إضافياً؟','ethics'],
  ['Can transparency ever cause more harm than secrecy?','هل يمكن للشفافية أن تسبب ضرراً أكبر من السرية؟','ethics'],
  ['Who should be accountable when a system makes a harmful decision?','من ينبغي أن يتحمل المسؤولية عندما يتخذ نظام قراراً ضاراً؟','ethics'],
  ['How should we act when every available option has a moral cost?','كيف نتصرف عندما تكون لكل الخيارات المتاحة كلفة أخلاقية؟','ethics'],
  ['What makes consent meaningful rather than merely formal?','ما الذي يجعل الموافقة حقيقية لا مجرد إجراء شكلي؟','ethics'],
 ],
 philosophy:[
  ['What makes a meaningful life?','ما الذي يمنح الحياة معنى؟','philosophy'],
  ['Do we become ourselves through our choices or our relationships?','هل نصبح ذواتنا من خلال خياراتنا أم علاقاتنا؟','philosophy'],
  ['What should count as progress in a human life?','ما الذي ينبغي اعتباره تقدماً في حياة الإنسان؟','philosophy'],
  ['Can a belief be useful even when we cannot prove it?','هل يمكن لمعتقد أن يكون مفيداً حتى إن لم نستطع إثباته؟','philosophy'],
  ['What does it mean to live freely within obligations to others?','ماذا يعني أن نعيش بحرية مع وجود التزامات تجاه الآخرين؟','philosophy'],
  ['Is wisdom mainly knowledge, judgment, or character?','هل الحكمة في جوهرها معرفة أم حكم سليم أم شخصية؟','philosophy'],
  ['How should uncertainty change the way we make important choices?','كيف ينبغي لعدم اليقين أن يغيّر طريقة اتخاذنا للخيارات المهمة؟','philosophy'],
 ],
 education:[
  ['Can AI make education more human?','هل يمكن للذكاء الاصطناعي أن يجعل التعليم أكثر إنسانية؟','education'],
  ['What should schools teach that exams cannot measure?','ما الذي ينبغي للمدارس تعليمه ولا تستطيع الاختبارات قياسه؟','education'],
  ['How can teachers support struggling students without lowering expectations?','كيف يدعم المعلمون الطلاب المتعثرين دون خفض التوقعات؟','education'],
  ['Should students have more influence over what and how they learn?','هل ينبغي أن يكون للطلاب تأثير أكبر في ما يتعلمونه وكيف يتعلمونه؟','education'],
  ['What is the fairest way to use technology in unequal classrooms?','ما أعدل طريقة لاستخدام التكنولوجيا في صفوف غير متكافئة؟','education'],
  ['How should universities balance career preparation and broad learning?','كيف توازن الجامعات بين الإعداد المهني والتعلم الواسع؟','education'],
  ['When does helpful feedback become excessive pressure?','متى تتحول الملاحظات المفيدة إلى ضغط مفرط؟','education'],
 ],
 technology:[
  ['Which decisions should never be delegated entirely to AI?','ما القرارات التي لا ينبغي تفويضها بالكامل للذكاء الاصطناعي؟','technology'],
  ['How much privacy should we trade for convenience?','ما مقدار الخصوصية الذي يمكن أن نتنازل عنه مقابل الراحة؟','technology'],
  ['Who benefits and who is left behind when a new technology is adopted?','من يستفيد ومن يُترك خلف الركب عند اعتماد تقنية جديدة؟','technology'],
  ['How can we tell whether automation is improving work or only accelerating it?','كيف نعرف ما إذا كانت الأتمتة تحسّن العمل أم تسرّعه فقط؟','technology'],
  ['Should digital platforms be responsible for the behaviour they encourage?','هل ينبغي للمنصات الرقمية أن تتحمل مسؤولية السلوك الذي تشجعه؟','technology'],
  ['What evidence should be required before trusting an AI recommendation?','ما الأدلة المطلوبة قبل الوثوق بتوصية يقدمها الذكاء الاصطناعي؟','technology'],
  ['How should children be prepared for a world shaped by intelligent machines?','كيف نُعِد الأطفال لعالم تشكله الآلات الذكية؟','technology'],
 ],
 personal:[
  ['How do I know whether I need patience or a real change?','كيف أعرف إن كنت بحاجة إلى الصبر أم إلى تغيير حقيقي؟','personal'],
  ['Which fear is protecting me, and which fear is limiting me?','أي خوف يحميني وأي خوف يقيّدني؟','personal'],
  ['What would a decision aligned with my values look like?','كيف يبدو القرار المنسجم مع قيمي؟','personal'],
  ['How should I choose between security and a meaningful opportunity?','كيف أختار بين الأمان وفرصة ذات معنى؟','personal'],
  ['What am I assuming about this situation that may not be true?','ما الذي أفترضه عن هذا الموقف وقد لا يكون صحيحاً؟','personal'],
  ['When is compromise wise, and when is it self-betrayal?','متى تكون التسوية حكمة، ومتى تكون تخلياً عن الذات؟','personal'],
  ['What small experiment could help me make this decision with better evidence?','ما التجربة الصغيرة التي تساعدني على اتخاذ هذا القرار بأدلة أفضل؟','personal'],
 ],
};
const questionHash=(value:string)=>[...value].reduce((sum,char)=>sum+char.charCodeAt(0),0);
export function dailyQuestionSuggestions(category:string,day:number,count=5):QuestionIdea[]{
 if(category&&questionBank[category]){const pool=questionBank[category];const start=(day*3+questionHash(category))%pool.length;return Array.from({length:Math.min(count,pool.length)},(_,i)=>pool[(start+i)%pool.length])}
 const ids=categories.map(([id])=>id);return Array.from({length:count},(_,i)=>{const id=ids[(day+i*3)%ids.length];const pool=questionBank[id];return pool[(day*2+i)%pool.length]})
}
export const examples=dailyQuestionSuggestions('',0,5);
export function categoryFor(q:string,fallback=''){const text=q.toLowerCase();const rules:[string,RegExp][]=[['religion',/religio|faith|god|islam|christ|دين|إسلام|مسيح|إيمان/],['family',/family|parent|teen|child|أسرة|أطفال|مراهق|والد/],['education',/educat|school|learn|student|تعليم|مدرس|تعلم|طالب/],['business',/business|team|work|market|company|موظف|عمل|شركة|فريق/],['technology',/\bai\b|tech|artificial|ذكاء|تقني/],['ethics',/ethic|moral|أخلاق/],['philosophy',/meaning|life|philosoph|حياة|فلسف/]];return rules.find(([,r])=>r.test(text))?.[0]||fallback||'personal'}
export function suggest(q:string,category:string,lang:Lang,count=5){
 const size=Math.min(5,Math.max(2,Number.isFinite(count)?Math.trunc(count):5));
 const c=category||categoryFor(q);
 const tokens=q.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(token=>token.length>2);
 const scored=catalogue.map((profile,index)=>{
  const library=profile.library??{};
  const haystack=[profile.name,profile.ar,profile.role,profile.expertise,profile.priorities,...profile.tags,...Object.values(library)].join(' ').toLowerCase();
  const categoryScore=profile.tags.includes(c)?20:0;
  const textScore=tokens.reduce((score,token)=>score+(haystack.includes(token)?2:0),0);
  return {profile,score:categoryScore+textScore,index};
 }).sort((a,b)=>b.score-a.score||a.index-b.index);
 const picked:Profile[]=[];
 for(const row of scored){
  if(picked.length>=size)break;
  const domain=row.profile.library?.Domain;
  if(picked.filter(profile=>profile.library?.Domain===domain).length<2) picked.push(row.profile);
 }
 for(const row of scored)if(picked.length<size&&!picked.some(profile=>profile.id===row.profile.id))picked.push(row.profile);
 return picked.slice(0,size).map(profile=>({...profile,reason:lang==='ar'?`${profile.prioritiesAr}. اختير لاختبار جانب مختلف من السؤال.`:`${profile.priorities}. Chosen to test a different tension in the question.`}));
}
export type Message={id:string;type:'participant'|'host'|'moderator'|'event';name:string;participantId?:string;seat?:number;text:string;label?:string;mode?:string};
export type Session={version:1;id:string;lang:Lang;question:string;context:string;category:string;goal:string;style:string;length:string;rounds:number;participantCount?:number;respectful:boolean;participants:Profile[];messages:Message[];turn:number;queue:string[];stage:'start'|'assemble'|'discuss';synthesis:string;synthesisAt:number;custom:Profile[];usageCharged?:boolean};
export const initialSession=():Session=>({version:1,id:crypto.randomUUID(),lang:'en',question:'',context:'',category:'',goal:'explore',style:'balanced',length:'medium',rounds:3,participantCount:5,respectful:true,participants:[],messages:[],turn:0,queue:[],stage:'start',synthesis:'',synthesisAt:0,custom:[],usageCharged:false});
export function nextSpeaker(s:Session){const queued=s.queue.find(id=>s.participants.some(p=>p.id===id));if(queued)return s.participants.findIndex(p=>p.id===queued);const counts=s.participants.map(p=>s.messages.filter(m=>m.type==='participant'&&m.participantId===p.id).length);return counts.indexOf(Math.min(...counts))}
export const nameOf=(p:Profile,l:Lang)=>l==='ar'?p.ar:p.name;
export const kindLabel=(p:Profile,l:Lang)=>l==='ar'?(p.kind==='public'?'محاكاة مستوحاة من أفكار عامة':p.kind==='custom'?'شخصية خيالية مخصصة':'منظور عام'):(p.kind==='public'?'Inspired AI simulation':p.kind==='custom'?'Custom fictional profile':'Generic perspective');
function validProfile(v:unknown):v is Profile{if(!v||typeof v!=='object')return false;const p=v as Profile;const brief=p.councilBrief;return ['id','name','ar','role','roleAr','group','expertise','expertiseAr','priorities','prioritiesAr'].every(k=>typeof (p as unknown as Record<string,unknown>)[k]==='string')&&['public','generic','custom'].includes(p.kind)&&Array.isArray(p.tags)&&p.tags.every(t=>typeof t==='string')&&(brief===undefined||Boolean(brief&&typeof brief.position==='string'&&typeof brief.tension==='string'&&typeof brief.reconsider==='string'))}
export function validateSession(v:unknown):v is Session{if(!v||typeof v!=='object')return false;const s=v as Session;const count=s.participantCount??5;return s.version===1&&['en','ar'].includes(s.lang)&&typeof s.id==='string'&&typeof s.question==='string'&&s.question.length<=2000&&typeof s.context==='string'&&s.context.length<=8000&&typeof s.category==='string'&&goals.some(g=>g[0]===s.goal)&&['balanced','collaborative','critical','socratic'].includes(s.style)&&['short','medium','detailed'].includes(s.length)&&Number.isInteger(count)&&count>=2&&count<=5&&typeof s.respectful==='boolean'&&(s.usageCharged===undefined||typeof s.usageCharged==='boolean')&&['start','assemble','discuss'].includes(s.stage)&&Array.isArray(s.participants)&&s.participants.length<=count&&(s.stage==='start'||s.participants.length===count)&&s.participants.every(validProfile)&&new Set(s.participants.map(p=>p.id)).size===s.participants.length&&Array.isArray(s.messages)&&s.messages.length<=220&&s.messages.every(m=>m&&typeof m.id==='string'&&typeof m.name==='string'&&['host','moderator','participant','event'].includes(m.type)&&typeof m.text==='string'&&m.text.length<=20000)&&Array.isArray(s.custom)&&s.custom.every(validProfile)&&Array.isArray(s.queue)&&s.queue.every(x=>typeof x==='string')&&Number.isInteger(s.turn)&&s.turn>=0&&Number.isInteger(s.rounds)&&s.rounds>=1&&s.rounds<=10&&Number.isInteger(s.synthesisAt)&&s.synthesisAt>=0&&typeof s.synthesis==='string'}
export function demoContribution(s:Session,seat:number){const p=s.participants[seat];const ar=s.lang==='ar';const host=[...s.messages].reverse().find(m=>m.type==='host');const last=[...s.messages].reverse().find(m=>m.type==='participant');const lens=ar?p.prioritiesAr:p.priorities;const prior=last?(ar?`أبني على نقطة ${last.name}، لكن أريد اختبار افتراض مختلف.`:`Building on ${last.name}’s point, I would test a different assumption.`):(ar?'لنبدأ بتحديد ما الذي سيجعل النتيجة مفيدة.':'Let’s first define what would make the outcome useful.');const response=ar?`${prior}\n\nمن زاويتي: ${lens}. عند مناقشة «${s.question}»، ينبغي مقارنة أثر الخيارات على الأشخاص المتأثرين، لا الاكتفاء بنية جيدة.${host?`\n\nأضفتَ: «${host.text}». سأتعامل مع هذه المداخلة كقيد يحتاج إلى اختبار قبل التوصية.`:''}\n\n${s.turn%3===0?'اقتراح للاختبار: جرّب خياراً محدوداً وقابلاً للتراجع، وحدد مقياس النجاح مسبقاً.':s.turn%3===1?'اعتراض محتمل: قد ينجح الحل في المتوسط لكنه ينقل العبء إلى أشخاص أقل قدرة على الاعتراض.':'سؤال مفتوح: ما الدليل الذي قد يدفعنا لتغيير موقفنا؟'}\n\nهذا مثال توضيحي مكتوب مسبقاً؛ لا يحلل سؤالك تحليلاً حياً.`:`${prior}\n\nMy lens is to ${lens.charAt(0).toLowerCase()+lens.slice(1)}. For “${s.question}”, compare what each option asks of the people affected, rather than relying on good intentions.${host?`\n\nYou added: “${host.text}”. I would treat that intervention as a constraint to test before recommending a course of action.`:''}\n\n${s.turn%3===0?'A possible test: try a small, reversible version and agree on success measures before starting.':s.turn%3===1?'A challenge: an option may work on average while shifting the burden to people with less power to object.':'An open question: what evidence would make us change our position?'}\n\nThis is a scripted demonstration, not live analysis of your question.`;if(s.length==='short')return response.split('\n\n').slice(0,host?3:2).join('\n\n');return response+(s.length==='detailed'?(ar?'\n\nمثال افتراضي: قارن تجربة صغيرة بالوضع الحالي، واسأل كل متأثر عن أثرها عليه قبل تعميمها.':'\n\nHypothetical example: compare a small pilot with the current arrangement and ask affected people about its impact before expanding it.'):'')}
export function demoSynthesis(s:Session){const ar=s.lang==='ar';const participants=s.messages.filter(m=>m.type==='participant');const host=s.messages.filter(m=>m.type==='host');const list=s.participants.map(p=>`• ${nameOf(p,s.lang)}: ${ar?p.prioritiesAr:p.priorities}`).join('\n');const formats:Record<string,string>={business:ar?'الخيارات والمفاضلات والمخاطر والإجراءات':'Options, tradeoffs, risks, and actions',family:ar?'الاحتياجات والمخاوف والتسويات وأسئلة الحوار':'Needs, concerns, compromises, and conversation prompts',religion:ar?'التفسيرات والمبادئ والتوترات والأسئلة المفتوحة':'Interpretations, principles, tensions, and open questions',ethics:ar?'المبادئ المتنافسة والتوترات الأخلاقية':'Competing principles and ethical tensions'};const frame=s.goal==='thesis'?(ar?'الادعاء والحجج والاعتراضات والأطروحة المنقحة':'Claim, supporting arguments, strongest objections, and refined thesis'):formats[categoryFor(s.question,s.category)]||(ar?'الخيارات والنتيجة والخطوات التالية':'Options, conclusion, and next steps');return ar?`خلاصة توضيحية — ليست تحليلاً حياً أو تأييداً من أي شخصية\n\nالسؤال المركزي\n${s.question}\n\nالمنظورات الرئيسية\n${list}\n\nما جرى\n${participants.length} مساهمة و${host.length} مداخلة من المضيف.\n${host.map(m=>'• '+m.text).join('\n')}\n\nنقاط الاتفاق\nلم يتم التحقق من وجود اتفاق فعلي. اختبر ما إذا كان المشاركون يقبلون معيار نجاح مشتركاً.\n\nالخلافات المهمة\nقارن الأولوية للنتائج مع العدالة والاستقلال والمخاطر. لا تفترض الإجماع.\n\nالافتراضات وعدم اليقين\n${s.context||'لم تضف سياقاً بعد.'}\nلا توجد مصادر متحقق منها في الوضع التوضيحي.\n\n${frame}\nقارن الوضع الحالي بتجربة محدودة وبخيار بديل. قيّم من يستفيد ومن يتحمل التكلفة. هذه بنية مقترحة وليست نتيجة مستخلصة.\n\nالخطوات التالية\n1. حدد القرار أو السؤال بدقة.\n2. اجمع أدلة وآراء الأشخاص المتأثرين.\n3. سجل الاعتراض الأقوى واختبره.\n4. حدد مسؤولاً وموعد مراجعة ومعيار نجاح.`:`Demonstration synthesis — not live analysis or an endorsement by any represented figure\n\nCentral question\n${s.question}\n\nMain perspectives\n${list}\n\nDiscussion record\n${participants.length} contributions and ${host.length} host interventions.\n${host.map(m=>'• '+m.text).join('\n')}\n\nAreas of agreement\nNo actual agreement has been verified. Test whether the table accepts a shared success criterion.\n\nImportant disagreements\nCompare outcome-focused priorities with fairness, autonomy, and downside risk. Do not assume consensus.\n\nAssumptions and uncertainties\n${s.context||'No background context supplied.'}\nNo sources were verified in demonstration mode.\n\n${frame}\nCompare the current arrangement, a limited experiment, and an alternative. Ask who benefits and who bears the cost. This is a suggested structure, not a derived conclusion.\n\nPractical next steps\n1. Define the decision or question precisely.\n2. Gather evidence and views from affected people.\n3. Record and test the strongest objection.\n4. Assign an owner, review date, and success measure.`}
