import { env } from "cloudflare:workers";

const COOKIE = "council_session";
const SESSION_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const USAGE_WINDOW_MS = 24 * 60 * 60 * 1000;
const FREE_LIMIT = 2;
const OWNER_PREMIUM_EMAIL = "eng.emadhanna84@gmail.com";
const UNLIMITED_DISPLAY_LIMIT = 999999;

export type AccountRow = {
  id: string;
  email: string;
  display_name: string;
  avatar_data: string;
  plan: string;
  preferred_lang: string;
};

const database = () =>
  (env as unknown as { COUNCIL_DB: D1Database }).COUNCIL_DB;

const bytesToBase64 = (bytes: Uint8Array) =>
  btoa(String.fromCharCode(...bytes));

const base64ToBytes = (value: string) =>
  Uint8Array.from(atob(value), (character) => character.charCodeAt(0));

const randomToken = () =>
  bytesToBase64(crypto.getRandomValues(new Uint8Array(32)))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");

const digest = async (value: string) => {
  const result = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(result), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
};

export async function passwordHash(password: string, salt: Uint8Array) {
  // Cloudflare Workers currently caps PBKDF2 at 100,000 iterations.
  const material = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new Uint8Array(salt).buffer,
      iterations: 100000,
      hash: "SHA-256",
    },
    material,
    256,
  );
  return bytesToBase64(new Uint8Array(bits));
}

export const encodeSalt = bytesToBase64;
export const decodeSalt = base64ToBytes;

function cookieValue(request: Request) {
  const header = request.headers.get("cookie") || "";
  const match = header.match(/(?:^|;\s*)council_session=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

export async function accountForRequest(
  request: Request,
): Promise<AccountRow | null> {
  const token = cookieValue(request);
  if (!token) return null;
  const tokenHash = await digest(token);
  const row = await database()
    .prepare(
      `SELECT users.id, users.email, users.display_name, users.avatar_data, users.plan, users.preferred_lang
       FROM account_sessions JOIN users ON users.id = account_sessions.user_id
       WHERE account_sessions.token_hash = ? AND account_sessions.expires_at > ?`,
    )
    .bind(tokenHash, Date.now())
    .first<AccountRow>();
  return row || null;
}

export async function createSession(userId: string) {
  const token = randomToken();
  const now = Date.now();
  await database()
    .prepare(
      "INSERT INTO account_sessions (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
    )
    .bind(
      crypto.randomUUID(),
      userId,
      await digest(token),
      now + SESSION_AGE_MS,
      now,
    )
    .run();
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${Math.floor(SESSION_AGE_MS / 1000)}`;
}

export async function clearSession(request: Request) {
  const token = cookieValue(request);
  if (token) {
    await database()
      .prepare("DELETE FROM account_sessions WHERE token_hash = ?")
      .bind(await digest(token))
      .run();
  }
  return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

export async function usageForAccount(account: AccountRow) {
  if (account.plan === "premium" || account.email.toLowerCase() === OWNER_PREMIUM_EMAIL) {
    return { limit: UNLIMITED_DISPLAY_LIMIT, used: 0, remaining: UNLIMITED_DISPLAY_LIMIT, resetAt: null };
  }
  const since = Date.now() - USAGE_WINDOW_MS;
  const rows = await database()
    .prepare(
      "SELECT started_at FROM usage_events WHERE user_id = ? AND started_at > ? ORDER BY started_at ASC",
    )
    .bind(account.id, since)
    .all<{ started_at: number }>();
  const limit = account.plan === "paid" ? 20 : FREE_LIMIT;
  const events = rows.results || [];
  return {
    limit,
    used: events.length,
    remaining: Math.max(0, limit - events.length),
    resetAt: events.length ? events[0].started_at + USAGE_WINDOW_MS : null,
  };
}

export async function consumeUsage(request: Request) {
  const account = await accountForRequest(request);
  if (!account) return null;
  const usage = await usageForAccount(account);
  if (account.plan === "premium" || account.email.toLowerCase() === OWNER_PREMIUM_EMAIL) {
    return { account, usage, consumed: true };
  }
  if (usage.remaining <= 0) return { account, usage, consumed: false };
  await database()
    .prepare(
      "INSERT INTO usage_events (id, user_id, started_at) VALUES (?, ?, ?)",
    )
    .bind(crypto.randomUUID(), account.id, Date.now())
    .run();
  return { account, usage: await usageForAccount(account), consumed: true };
}

export { database };
