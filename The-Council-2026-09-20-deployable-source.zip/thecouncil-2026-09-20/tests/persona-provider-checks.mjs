import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';

const source=fs.readFileSync('app/api/personas/route.ts','utf8').replace("@/lib/roundtable","../lib/roundtable.ts");
fs.writeFileSync('work/persona-route-check.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
process.env.MOONSHOT_API_KEY='test-only-not-a-real-key';
let sent;
global.fetch=async(_url,init)=>{sent=JSON.parse(init.body);return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify({selections:[{id:'strategist',reason:'Tests implementation feasibility.'},{id:'employee',reason:'Tests workload impact.'},{id:'economist',reason:'Tests incentives and tradeoffs.'}]})}}]}),{status:200,headers:{'Content-Type':'application/json'}})};
const api=await import('../work/persona-route-check.mjs');
const request=()=>new Request('http://localhost/api/personas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:'How can a factory reduce defects without more overtime?',category:'business',lang:'en',count:3})});
let response=await api.POST(request());let result=await response.json();
assert.equal(response.status,200);assert.equal(result.mode,'live');assert.deepEqual(result.selections.map(row=>row.id),['strategist','employee','economist']);
assert.equal(sent.thinking.type,'disabled');assert.equal(sent.messages.length,2);assert(JSON.parse(sent.messages[1].content).catalogue.length>=32);
console.log('PASS Kimi persona matching returns validated catalogue IDs with reasons');
global.fetch=async()=>new Response('provider unavailable',{status:500});response=await api.POST(request());result=await response.json();assert.equal(response.status,200);assert.equal(result.mode,'fallback');assert.equal(result.selections.length,3);
console.log('PASS persona matching falls back safely when Kimi is unavailable');
delete process.env.MOONSHOT_API_KEY;
