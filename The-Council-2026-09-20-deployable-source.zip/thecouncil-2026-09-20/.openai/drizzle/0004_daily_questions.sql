CREATE TABLE IF NOT EXISTS daily_questions (
  day_key TEXT PRIMARY KEY,
  questions_json TEXT NOT NULL,
  generated_at INTEGER NOT NULL
);

