DELETE FROM account_sessions
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'codex-auth-check-20260919@example.invalid'
);

DELETE FROM discussions
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'codex-auth-check-20260919@example.invalid'
);

DELETE FROM usage_events
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'codex-auth-check-20260919@example.invalid'
);

DELETE FROM users
WHERE email = 'codex-auth-check-20260919@example.invalid';
