UPDATE users
SET plan = 'premium', updated_at = CAST(strftime('%s', 'now') AS INTEGER) * 1000
WHERE lower(email) = 'eng.emadhanna84@gmail.com';
